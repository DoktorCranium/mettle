/* Generated file -- DO NOT EDIT */

#define WIDE_UINT_BITS 128
P (1, 26,
   (((((uintmax_t) 0xaaaaU << 28 | 0xaaaaaaaU)
      << 28 | 0xaaaaaaaU)
     << 28 | 0xaaaaaaaU)
    << 28 | 0xaaaaaabU),
   UINTMAX_MAX / 3)
P (2, 26,
   (((((uintmax_t) 0xccccU << 28 | 0xcccccccU)
      << 28 | 0xcccccccU)
     << 28 | 0xcccccccU)
    << 28 | 0xccccccdU),
   UINTMAX_MAX / 5)
P (2, 30,
   (((((uintmax_t) 0xb6dbU << 28 | 0x6db6db6U)
      << 28 | 0xdb6db6dU)
     << 28 | 0xb6db6dbU)
    << 28 | 0x6db6db7U),
   UINTMAX_MAX / 7)
P (4, 30,
   (((((uintmax_t) 0xa2e8U << 28 | 0xba2e8baU)
      << 28 | 0x2e8ba2eU)
     << 28 | 0x8ba2e8bU)
    << 28 | 0xa2e8ba3U),
   UINTMAX_MAX / 11)
P (2, 30,
   (((((uintmax_t) 0xc4ecU << 28 | 0x4ec4ec4U)
      << 28 | 0xec4ec4eU)
     << 28 | 0xc4ec4ecU)
    << 28 | 0x4ec4ec5U),
   UINTMAX_MAX / 13)
P (4, 30,
   (((((uintmax_t) 0xf0f0U << 28 | 0xf0f0f0fU)
      << 28 | 0x0f0f0f0U)
     << 28 | 0xf0f0f0fU)
    << 28 | 0x0f0f0f1U),
   UINTMAX_MAX / 17)
P (2, 34,
   (((((uintmax_t) 0xbca1U << 28 | 0xaf286bcU)
      << 28 | 0xa1af286U)
     << 28 | 0xbca1af2U)
    << 28 | 0x86bca1bU),
   UINTMAX_MAX / 19)
P (4, 36,
   (((((uintmax_t) 0x4de9U << 28 | 0xbd37a6fU)
      << 28 | 0x4de9bd3U)
     << 28 | 0x7a6f4deU)
    << 28 | 0x9bd37a7U),
   UINTMAX_MAX / 23)
P (6, 32,
   (((((uintmax_t) 0xc234U << 28 | 0xf72c234U)
      << 28 | 0xf72c234U)
     << 28 | 0xf72c234U)
    << 28 | 0xf72c235U),
   UINTMAX_MAX / 29)
P (2, 36,
   (((((uintmax_t) 0xdef7U << 28 | 0xbdef7bdU)
      << 28 | 0xef7bdefU)
     << 28 | 0x7bdef7bU)
    << 28 | 0xdef7bdfU),
   UINTMAX_MAX / 31)
P (6, 34,
   (((((uintmax_t) 0xc1baU << 28 | 0xcf914c1U)
      << 28 | 0xbacf914U)
     << 28 | 0xc1bacf9U)
    << 28 | 0x14c1badU),
   UINTMAX_MAX / 37)
P (4, 32,
   (((((uintmax_t) 0x18f9U << 28 | 0xc18f9c1U)
      << 28 | 0x8f9c18fU)
     << 28 | 0x9c18f9cU)
    << 28 | 0x18f9c19U),
   UINTMAX_MAX / 41)
P (2, 36,
   (((((uintmax_t) 0xbe82U << 28 | 0xfa0be82U)
      << 28 | 0xfa0be82U)
     << 28 | 0xfa0be82U)
    << 28 | 0xfa0be83U),
   UINTMAX_MAX / 43)
P (4, 36,
   (((((uintmax_t) 0x3677U << 28 | 0xd46cefaU)
      << 28 | 0x8d9df51U)
     << 28 | 0xb3bea36U)
    << 28 | 0x77d46cfU),
   UINTMAX_MAX / 47)
P (6, 36,
   (((((uintmax_t) 0x1352U << 28 | 0x1cfb2b7U)
      << 28 | 0x8c13521U)
     << 28 | 0xcfb2b78U)
    << 28 | 0xc13521dU),
   UINTMAX_MAX / 53)
P (6, 38,
   (((((uintmax_t) 0x8f2fU << 28 | 0xba93868U)
      << 28 | 0x22b63cbU)
     << 28 | 0xeea4e1aU)
    << 28 | 0x08ad8f3U),
   UINTMAX_MAX / 59)
P (2, 40,
   (((((uintmax_t) 0x14fbU << 28 | 0xcda3ac1U)
      << 28 | 0x0c9714fU)
     << 28 | 0xbcda3acU)
    << 28 | 0x10c9715U),
   UINTMAX_MAX / 61)
P (6, 36,
   (((((uintmax_t) 0xc2ddU << 28 | 0x9ca81e9U)
      << 28 | 0x131abf0U)
     << 28 | 0xb7672a0U)
    << 28 | 0x7a44c6bU),
   UINTMAX_MAX / 67)
P (4, 36,
   (((((uintmax_t) 0x4f52U << 28 | 0xedf8c9eU)
      << 28 | 0xa5dbf19U)
     << 28 | 0x3d4bb7eU)
    << 28 | 0x327a977U),
   UINTMAX_MAX / 71)
P (2, 36,
   (((((uintmax_t) 0x3f1fU << 28 | 0x8fc7e3fU)
      << 28 | 0x1f8fc7eU)
     << 28 | 0x3f1f8fcU)
    << 28 | 0x7e3f1f9U),
   UINTMAX_MAX / 73)
P (6, 34,
   (((((uintmax_t) 0xd5dfU << 28 | 0x984dc5aU)
      << 28 | 0xbbf309bU)
     << 28 | 0x8b577e6U)
    << 28 | 0x13716afU),
   UINTMAX_MAX / 79)
P (4, 44,
   (((((uintmax_t) 0x2818U << 28 | 0xacb90f6U)
      << 28 | 0xbf3a9a3U)
     << 28 | 0x784a062U)
    << 28 | 0xb2e43dbU),
   UINTMAX_MAX / 83)
P (6, 42,
   (((((uintmax_t) 0xd1faU << 28 | 0x3f47e8fU)
      << 28 | 0xd1fa3f4U)
     << 28 | 0x7e8fd1fU)
    << 28 | 0xa3f47e9U),
   UINTMAX_MAX / 89)
P (8, 40,
   (((((uintmax_t) 0x5f02U << 28 | 0xa3a0fd5U)
      << 28 | 0xc5f02a3U)
     << 28 | 0xa0fd5c5U)
    << 28 | 0xf02a3a1U),
   UINTMAX_MAX / 97)
P (4, 38,
   (((((uintmax_t) 0xc32bU << 28 | 0x16cfd77U)
      << 28 | 0x20f353aU)
     << 28 | 0x4c0a237U)
    << 28 | 0xc32b16dU),
   UINTMAX_MAX / 101)
P (2, 46,
   (((((uintmax_t) 0xd0c6U << 28 | 0xd5bf60eU)
      << 28 | 0xe9a18daU)
     << 28 | 0xb7ec1ddU)
    << 28 | 0x3431b57U),
   UINTMAX_MAX / 103)
P (4, 44,
   (((((uintmax_t) 0xa2b1U << 28 | 0x0bf66e0U)
      << 28 | 0xe5aea77U)
     << 28 | 0xa04c8f8U)
    << 28 | 0xd28ac43U),
   UINTMAX_MAX / 107)
P (2, 48,
   (((((uintmax_t) 0xc096U << 28 | 0x4fda6c0U)
      << 28 | 0x964fda6U)
     << 28 | 0xc0964fdU)
    << 28 | 0xa6c0965U),
   UINTMAX_MAX / 109)
P (4, 50,
   (((((uintmax_t) 0xc090U << 28 | 0xfdbc090U)
      << 28 | 0xfdbc090U)
     << 28 | 0xfdbc090U)
    << 28 | 0xfdbc091U),
   UINTMAX_MAX / 113)
P (14, 40,
   (((((uintmax_t) 0xbf7eU << 28 | 0xfdfbf7eU)
      << 28 | 0xfdfbf7eU)
     << 28 | 0xfdfbf7eU)
    << 28 | 0xfdfbf7fU),
   UINTMAX_MAX / 127)
P (4, 42,
   (((((uintmax_t) 0xf82eU << 28 | 0xe6986d6U)
      << 28 | 0xf63aa03U)
     << 28 | 0xe88cb3cU)
    << 28 | 0x9484e2bU),
   UINTMAX_MAX / 131)
P (6, 42,
   (((((uintmax_t) 0x21a2U << 28 | 0x91c0779U)
      << 28 | 0x75b8fe2U)
     << 28 | 0x1a291c0U)
    << 28 | 0x77975b9U),
   UINTMAX_MAX / 137)
P (2, 42,
   (((((uintmax_t) 0xa212U << 28 | 0x6ad1f4fU)
      << 28 | 0x31ba03aU)
     << 28 | 0xef6ca97U)
    << 28 | 0x0586723U),
   UINTMAX_MAX / 139)
P (10, 42,
   (((((uintmax_t) 0x93c2U << 28 | 0x25cc74dU)
      << 28 | 0x50c06dfU)
     << 28 | 0x5b0f768U)
    << 28 | 0xce2cabdU),
   UINTMAX_MAX / 149)
P (2, 42,
   (((((uintmax_t) 0x26feU << 28 | 0x4dfc9bfU)
      << 28 | 0x937f26fU)
     << 28 | 0xe4dfc9bU)
    << 28 | 0xf937f27U),
   UINTMAX_MAX / 151)
P (6, 40,
   (((((uintmax_t) 0x0685U << 28 | 0xb4fe5e9U)
      << 28 | 0x2c0685bU)
     << 28 | 0x4fe5e92U)
    << 28 | 0xc0685b5U),
   UINTMAX_MAX / 157)
P (6, 36,
   (((((uintmax_t) 0x8bc7U << 28 | 0x75ca99eU)
      << 28 | 0xa03241fU)
     << 28 | 0x693a1c4U)
    << 28 | 0x51ab30bU),
   UINTMAX_MAX / 163)
P (4, 44,
   (((((uintmax_t) 0x513eU << 28 | 0xd9ad38bU)
      << 28 | 0x7f3bc8dU)
     << 28 | 0x07aa27dU)
    << 28 | 0xb35a717U),
   UINTMAX_MAX / 167)
P (6, 50,
   (((((uintmax_t) 0x133cU << 28 | 0xaba736cU)
      << 28 | 0x05eb488U)
     << 28 | 0x2383b30U)
    << 28 | 0xd516325U),
   UINTMAX_MAX / 173)
P (6, 48,
   (((((uintmax_t) 0x0e4dU << 28 | 0x3aa30a0U)
      << 28 | 0x2dc3eedU)
     << 28 | 0x6866f8dU)
    << 28 | 0x962ae7bU),
   UINTMAX_MAX / 179)
P (2, 48,
   (((((uintmax_t) 0x6fbcU << 28 | 0x1c498c0U)
      << 28 | 0x5a84f34U)
     << 28 | 0x54dca41U)
    << 28 | 0x0f8ed9dU),
   UINTMAX_MAX / 181)
P (10, 42,
   (((((uintmax_t) 0x7749U << 28 | 0xb79f7f5U)
      << 28 | 0x470961dU)
     << 28 | 0x7ca632eU)
    << 28 | 0xe936f3fU),
   UINTMAX_MAX / 191)
P (2, 46,
   (((((uintmax_t) 0x9094U << 28 | 0x8f40feaU)
      << 28 | 0xc6f6b70U)
     << 28 | 0xbf01539U)
    << 28 | 0x0948f41U),
   UINTMAX_MAX / 193)
P (4, 44,
   (((((uintmax_t) 0x0bb2U << 28 | 0x07cc053U)
      << 28 | 0x2ae21c9U)
     << 28 | 0x6bdb9d3U)
    << 28 | 0xd137e0dU),
   UINTMAX_MAX / 197)
P (2, 52,
   (((((uintmax_t) 0x7a36U << 28 | 0x07b7f5bU)
      << 28 | 0x5630e26U)
     << 28 | 0x97cc8aeU)
    << 28 | 0xf46c0f7U),
   UINTMAX_MAX / 199)
P (12, 46,
   (((((uintmax_t) 0x2f51U << 28 | 0x4a026d3U)
      << 28 | 0x1be7bc0U)
     << 28 | 0xe8f2a76U)
    << 28 | 0xe68575bU),
   UINTMAX_MAX / 211)
P (12, 40,
   (((((uintmax_t) 0xdd8fU << 28 | 0x7f6d0eeU)
      << 28 | 0xc7bfb68U)
     << 28 | 0x7763dfdU)
    << 28 | 0xb43bb1fU),
   UINTMAX_MAX / 223)
P (4, 42,
   (((((uintmax_t) 0x766aU << 28 | 0x024168eU)
      << 28 | 0x18cf81bU)
     << 28 | 0x10ea929U)
    << 28 | 0xba144cbU),
   UINTMAX_MAX / 227)
P (2, 42,
   (((((uintmax_t) 0x0c4cU << 28 | 0x0478bbcU)
      << 28 | 0xecfee1dU)
     << 28 | 0x10c4c04U)
    << 28 | 0x78bbcedU),
   UINTMAX_MAX / 229)
P (4, 44,
   (((((uintmax_t) 0x758fU << 28 | 0xee6bac7U)
      << 28 | 0xf735d63U)
     << 28 | 0xfb9aeb1U)
    << 28 | 0xfdcd759U),
   UINTMAX_MAX / 233)
P (6, 42,
   (((((uintmax_t) 0x077fU << 28 | 0x76e538cU)
      << 28 | 0x5167e64U)
     << 28 | 0xafaa4f4U)
    << 28 | 0x37b2e0fU),
   UINTMAX_MAX / 239)
P (2, 42,
   (((((uintmax_t) 0x10feU << 28 | 0xf010fefU)
      << 28 | 0x010fef0U)
     << 28 | 0x10fef01U)
    << 28 | 0x0fef011U),
   UINTMAX_MAX / 241)
P (10, 42,
   (((((uintmax_t) 0xa020U << 28 | 0xa32fefaU)
      << 28 | 0xe680828U)
     << 28 | 0xcbfbeb9U)
    << 28 | 0xa020a33U),
   UINTMAX_MAX / 251)
P (6, 50,
   (((((uintmax_t) 0xff00U << 28 | 0xff00ff0U)
      << 28 | 0x0ff00ffU)
     << 28 | 0x00ff00fU)
    << 28 | 0xf00ff01U),
   UINTMAX_MAX / 257)
P (6, 48,
   (((((uintmax_t) 0xf836U << 28 | 0x826ef73U)
      << 28 | 0xd52bcd6U)
     << 28 | 0x24fd147U)
    << 28 | 0x0e99cb7U),
   UINTMAX_MAX / 263)
P (6, 44,
   (((((uintmax_t) 0x3ce8U << 28 | 0x354b2eaU)
      << 28 | 0x1c8cd8fU)
     << 28 | 0xb3ddbd6U)
    << 28 | 0x205b5c5U),
   UINTMAX_MAX / 269)
P (2, 46,
   (((((uintmax_t) 0x8715U << 28 | 0xba188f9U)
      << 28 | 0x63302d5U)
     << 28 | 0x7da36caU)
    << 28 | 0x27acdefU),
   UINTMAX_MAX / 271)
P (6, 54,
   (((((uintmax_t) 0xb25eU << 28 | 0x4463cffU)
      << 28 | 0x13686eeU)
     << 28 | 0x70c03b2U)
    << 28 | 0x5e4463dU),
   UINTMAX_MAX / 277)
P (4, 56,
   (((((uintmax_t) 0x6c69U << 28 | 0xae01d27U)
      << 28 | 0x2ca3fc5U)
     << 28 | 0xb1a6b80U)
    << 28 | 0x749cb29U),
   UINTMAX_MAX / 281)
P (2, 64,
   (((((uintmax_t) 0xf26eU << 28 | 0x5c44bfcU)
      << 28 | 0x61b2347U)
     << 28 | 0x768073cU)
    << 28 | 0x9b97113U),
   UINTMAX_MAX / 283)
P (10, 56,
   (((((uintmax_t) 0xb07dU << 28 | 0xd0d1b15U)
      << 28 | 0xd7cf125U)
     << 28 | 0x91e9488U)
    << 28 | 0x4ce32adU),
   UINTMAX_MAX / 293)
P (14, 46,
   (((((uintmax_t) 0xd2f8U << 28 | 0x7ebfcaaU)
      << 28 | 0x1c5a0f0U)
     << 28 | 0x2806abcU)
    << 28 | 0x74be1fbU),
   UINTMAX_MAX / 307)
P (4, 48,
   (((((uintmax_t) 0xbe25U << 28 | 0xdd6d7aaU)
      << 28 | 0x646ca7eU)
     << 28 | 0xc3e8f3aU)
    << 28 | 0x7198487U),
   UINTMAX_MAX / 311)
P (2, 54,
   (((((uintmax_t) 0xbc1dU << 28 | 0x71afd8bU)
      << 28 | 0xdc03458U)
     << 28 | 0x550f8a3U)
    << 28 | 0x9409d09U),
   UINTMAX_MAX / 313)
P (4, 56,
   (((((uintmax_t) 0x2ed6U << 28 | 0xd05a72aU)
      << 28 | 0xcd1f7ecU)
     << 28 | 0x9e48ae6U)
    << 28 | 0xf71de15U),
   UINTMAX_MAX / 317)
P (14, 48,
   (((((uintmax_t) 0x62ffU << 28 | 0x3a018bfU)
      << 28 | 0xce8062fU)
     << 28 | 0xf3a018bU)
    << 28 | 0xfce8063U),
   UINTMAX_MAX / 331)
P (6, 46,
   (((((uintmax_t) 0x3fcfU << 28 | 0x61fe7b0U)
      << 28 | 0xff3d87fU)
     << 28 | 0x9ec3fcfU)
    << 28 | 0x61fe7b1U),
   UINTMAX_MAX / 337)
P (10, 42,
   (((((uintmax_t) 0x398bU << 28 | 0x6f668c2U)
      << 28 | 0xc43df89U)
     << 28 | 0xf5abe57U)
    << 28 | 0x0e046d3U),
   UINTMAX_MAX / 347)
P (2, 48,
   (((((uintmax_t) 0x8c1aU << 28 | 0x682913cU)
      << 28 | 0xe1ecedaU)
     << 28 | 0x971b23fU)
    << 28 | 0x1545af5U),
   UINTMAX_MAX / 349)
P (4, 48,
   (((((uintmax_t) 0x0b9aU << 28 | 0x7862a0fU)
      << 28 | 0xf465879U)
     << 28 | 0xd5f00b9U)
    << 28 | 0xa7862a1U),
   UINTMAX_MAX / 353)
P (6, 50,
   (((((uintmax_t) 0xe7c1U << 28 | 0x3f77161U)
      << 28 | 0xb18f54dU)
     << 28 | 0xba1df32U)
    << 28 | 0xa128a57U),
   UINTMAX_MAX / 359)
P (8, 52,
   (((((uintmax_t) 0x7318U << 28 | 0x6a06f9bU)
      << 28 | 0x8d9a287U)
     << 28 | 0x530217bU)
    << 28 | 0x7747d8fU),
   UINTMAX_MAX / 367)
P (6, 48,
   (((((uintmax_t) 0x7c39U << 28 | 0xa6c708eU)
      << 28 | 0xc18b530U)
     << 28 | 0xbaae53bU)
    << 28 | 0xb5e06ddU),
   UINTMAX_MAX / 373)
P (6, 52,
   (((((uintmax_t) 0x3763U << 28 | 0x4af9ebbU)
      << 28 | 0xc742deeU)
     << 28 | 0x70206c1U)
    << 28 | 0x2e9b5b3U),
   UINTMAX_MAX / 379)
P (4, 50,
   (((((uintmax_t) 0x5035U << 28 | 0x78fb523U)
      << 28 | 0x6cf34cdU)
     << 28 | 0xde9462eU)
    << 28 | 0xc9dbe7fU),
   UINTMAX_MAX / 383)
P (6, 50,
   (((((uintmax_t) 0xbcdfU << 28 | 0xc0d2975U)
      << 28 | 0xccab1afU)
     << 28 | 0xb64b05eU)
    << 28 | 0xc41cf4dU),
   UINTMAX_MAX / 389)
P (8, 46,
   (((((uintmax_t) 0xf5aeU << 28 | 0xc02944fU)
      << 28 | 0xf5aec02U)
     << 28 | 0x944ff5aU)
    << 28 | 0xec02945U),
   UINTMAX_MAX / 397)
P (4, 48,
   (((((uintmax_t) 0xc7d2U << 28 | 0x08f00a3U)
      << 28 | 0x6e71a2cU)
     << 28 | 0xb033128U)
    << 28 | 0x382df71U),
   UINTMAX_MAX / 401)
P (8, 48,
   (((((uintmax_t) 0xd38fU << 28 | 0x55c0280U)
      << 28 | 0xf05a21cU)
     << 28 | 0xcacc0c8U)
    << 28 | 0x4b1c2a9U),
   UINTMAX_MAX / 409)
P (10, 42,
   (((((uintmax_t) 0xca3bU << 28 | 0xe03aa76U)
      << 28 | 0x87a3219U)
     << 28 | 0xa93db57U)
    << 28 | 0x5eb3a0bU),
   UINTMAX_MAX / 419)
P (2, 42,
   (((((uintmax_t) 0x6a69U << 28 | 0xce2344bU)
      << 28 | 0x66c3cceU)
     << 28 | 0xbeef94fU)
    << 28 | 0xa86fe2dU),
   UINTMAX_MAX / 421)
P (10, 36,
   (((((uintmax_t) 0xfecfU << 28 | 0xe37d53bU)
      << 28 | 0xfd9fc6fU)
     << 28 | 0xaa77fb3U)
    << 28 | 0xf8df54fU),
   UINTMAX_MAX / 431)
P (2, 46,
   (((((uintmax_t) 0xa58aU << 28 | 0xf00975aU)
      << 28 | 0x750ff68U)
     << 28 | 0xa58af00U)
    << 28 | 0x975a751U),
   UINTMAX_MAX / 433)
P (6, 48,
   (((((uintmax_t) 0xdc6dU << 28 | 0xa187df5U)
      << 28 | 0x80dfed5U)
     << 28 | 0x6e36d0cU)
    << 28 | 0x3efac07U),
   UINTMAX_MAX / 439)
P (4, 48,
   (((((uintmax_t) 0x8fe4U << 28 | 0x4308ab0U)
      << 28 | 0xd4a8bd8U)
     << 28 | 0xb44c47aU)
    << 28 | 0x8299b73U),
   UINTMAX_MAX / 443)
P (6, 50,
   (((((uintmax_t) 0xf1bfU << 28 | 0x0091f5bU)
      << 28 | 0xcb8bb02U)
     << 28 | 0xd9ccaf9U)
    << 28 | 0xba70e41U),
   UINTMAX_MAX / 449)
P (8, 46,
   (((((uintmax_t) 0x5e1cU << 28 | 0x023d9e8U)
      << 28 | 0x78ff709U)
     << 28 | 0x85e1c02U)
    << 28 | 0x3d9e879U),
   UINTMAX_MAX / 457)
P (4, 48,
   (((((uintmax_t) 0x7880U << 28 | 0xd53da3dU)
      << 28 | 0x15a842aU)
     << 28 | 0x343316cU)
    << 28 | 0x494d305U),
   UINTMAX_MAX / 461)
P (2, 58,
   (((((uintmax_t) 0x1ddbU << 28 | 0x81ef699U)
      << 28 | 0xb5e8c70U)
     << 28 | 0xcb7916aU)
    << 28 | 0xb67652fU),
   UINTMAX_MAX / 463)
P (4, 56,
   (((((uintmax_t) 0xf364U << 28 | 0x5121706U)
      << 28 | 0x07acad3U)
     << 28 | 0x98f132fU)
    << 28 | 0xb10fe5bU),
   UINTMAX_MAX / 467)
P (12, 62,
   (((((uintmax_t) 0xadb1U << 28 | 0xf8848afU)
      << 28 | 0x4c6d06fU)
     << 28 | 0x2a38a6bU)
    << 28 | 0xf54fa1fU),
   UINTMAX_MAX / 479)
P (8, 60,
   (((((uintmax_t) 0xd9a0U << 28 | 0x541b55aU)
      << 28 | 0xf0c1721U)
     << 28 | 0x1df689bU)
    << 28 | 0x98f81d7U),
   UINTMAX_MAX / 487)
P (4, 66,
   (((((uintmax_t) 0x673bU << 28 | 0xf592825U)
      << 28 | 0x8a2ac0eU)
     << 28 | 0x994983eU)
    << 28 | 0x90f1ec3U),
   UINTMAX_MAX / 491)
P (8, 64,
   (((((uintmax_t) 0x0ddaU << 28 | 0x093c062U)
      << 28 | 0x8041aadU)
     << 28 | 0x671e44bU)
    << 28 | 0xed87f3bU),
   UINTMAX_MAX / 499)
P (4, 66,
   (((((uintmax_t) 0xa9fcU << 28 | 0xf24229bU)
      << 28 | 0xbcd1af9U)
     << 28 | 0x623a051U)
    << 28 | 0x6e70fc7U),
   UINTMAX_MAX / 503)
P (6, 62,
   (((((uintmax_t) 0xcbb1U << 28 | 0x8a4f773U)
      << 28 | 0x2cc324bU)
     << 28 | 0x7129be9U)
    << 28 | 0xdece355U),
   UINTMAX_MAX / 509)
P (12, 56,
   (((((uintmax_t) 0x01f7U << 28 | 0x27cce5fU)
      << 28 | 0x530a519U)
     << 28 | 0x0f3b747U)
    << 28 | 0x3f62c39U),
   UINTMAX_MAX / 521)
P (2, 64,
   (((((uintmax_t) 0x6da4U << 28 | 0xf4bdeb7U)
      << 28 | 0x1121c63U)
     << 28 | 0xdacc9aaU)
    << 28 | 0xd46f9a3U),
   UINTMAX_MAX / 523)
P (18, 52,
   (((((uintmax_t) 0x4d9aU << 28 | 0xbc552cfU)
      << 28 | 0x42b88c1U)
     << 28 | 0x108fda2U)
    << 28 | 0x4e8d035U),
   UINTMAX_MAX / 541)
P (6, 52,
   (((((uintmax_t) 0x141fU << 28 | 0xd312409U)
      << 28 | 0x5c328b7U)
     << 28 | 0x7578472U)
    << 28 | 0x319bd8bU),
   UINTMAX_MAX / 547)
P (10, 44,
   (((((uintmax_t) 0xddfdU << 28 | 0x3e0bf32U)
      << 28 | 0x18d1947U)
     << 28 | 0x3d20a1cU)
    << 28 | 0x7ed9da5U),
   UINTMAX_MAX / 557)
P (6, 44,
   (((((uintmax_t) 0xdb2bU << 28 | 0x3278f3bU)
      << 28 | 0x910d2fbU)
     << 28 | 0xe85af0fU)
    << 28 | 0xea2c8fbU),
   UINTMAX_MAX / 563)
P (6, 44,
   (((((uintmax_t) 0xcb5cU << 28 | 0x3b636e3U)
      << 28 | 0xa7d1358U)
     << 28 | 0xa1f7e6cU)
    << 28 | 0xe0f4c09U),
   UINTMAX_MAX / 569)
P (2, 46,
   (((((uintmax_t) 0x1bcbU << 28 | 0xfe34e75U)
      << 28 | 0x76cf21aU)
     << 28 | 0x00e58c5U)
    << 28 | 0x44986f3U),
   UINTMAX_MAX / 571)
P (6, 42,
   (((((uintmax_t) 0x6b5eU << 28 | 0x80aa5efU)
      << 28 | 0x23f0071U)
     << 28 | 0x94a17f5U)
    << 28 | 0x5a10dc1U),
   UINTMAX_MAX / 577)
P (10, 44,
   (((((uintmax_t) 0x9a62U << 28 | 0x8feb110U)
      << 28 | 0x22e3a70U)
     << 28 | 0x8494478U)
    << 28 | 0x5e33763U),
   UINTMAX_MAX / 587)
P (6, 48,
   (((((uintmax_t) 0xbe61U << 28 | 0x909eddeU)
      << 28 | 0x53c01baU)
     << 28 | 0x10679bdU)
    << 28 | 0x84886b1U),
   UINTMAX_MAX / 593)
P (6, 44,
   (((((uintmax_t) 0x4febU << 28 | 0x7c5e05fU)
      << 28 | 0xbb9e8ebU)
     << 28 | 0xe9c6bb3U)
    << 28 | 0x1260967U),
   UINTMAX_MAX / 599)
P (2, 46,
   (((((uintmax_t) 0x1ff2U << 28 | 0x5e8ff92U)
      << 28 | 0xf47fc97U)
     << 28 | 0xa3fe4bdU)
    << 28 | 0x1ff25e9U),
   UINTMAX_MAX / 601)
P (6, 46,
   (((((uintmax_t) 0x3014U << 28 | 0x3e6b1faU)
      << 28 | 0x187616cU)
     << 28 | 0x6388395U)
    << 28 | 0xb84d99fU),
   UINTMAX_MAX / 607)
P (6, 46,
   (((((uintmax_t) 0xd491U << 28 | 0x54c6c94U)
      << 28 | 0xac0f08cU)
     << 28 | 0x51da6a1U)
    << 28 | 0x335df6dU),
   UINTMAX_MAX / 613)
P (4, 44,
   (((((uintmax_t) 0x9b97U << 28 | 0x71454a4U)
      << 28 | 0x4e00d46U)
     << 28 | 0xf323447U)
    << 28 | 0x5d5add9U),
   UINTMAX_MAX / 617)
P (2, 54,
   (((((uintmax_t) 0x3abaU << 28 | 0x1b4baefU)
      << 28 | 0x0b2a990U)
     << 28 | 0x5605ca3U)
    << 28 | 0xc619a43U),
   UINTMAX_MAX / 619)
P (12, 46,
   (((((uintmax_t) 0xcc11U << 28 | 0xd9dd1bfU)
      << 28 | 0xe608eceU)
     << 28 | 0xe8dff30U)
    << 28 | 0x4767747U),
   UINTMAX_MAX / 631)
P (10, 42,
   (((((uintmax_t) 0xff99U << 28 | 0xc27f006U)
      << 28 | 0x63d80ffU)
     << 28 | 0x99c27f0U)
    << 28 | 0x0663d81U),
   UINTMAX_MAX / 641)
P (2, 48,
   (((((uintmax_t) 0x111eU << 28 | 0xa8032f6U)
      << 28 | 0x0bf1aacU)
     << 28 | 0xca407f6U)
    << 28 | 0x71ddc2bU),
   UINTMAX_MAX / 643)
P (4, 54,
   (((((uintmax_t) 0xdd93U << 28 | 0x95f5b66U)
      << 28 | 0x7aa88e7U)
     << 28 | 0x1298bacU)
    << 28 | 0x1e12337U),
   UINTMAX_MAX / 647)
P (6, 56,
   (((((uintmax_t) 0xa7caU << 28 | 0xaed9303U)
      << 28 | 0x8740afaU)
     << 28 | 0x1e94309U)
    << 28 | 0xcd09045U),
   UINTMAX_MAX / 653)
P (6, 60,
   (((((uintmax_t) 0x2be5U << 28 | 0x958f582U)
      << 28 | 0xe9db7beU)
     << 28 | 0xbccb8e9U)
    << 28 | 0x1496b9bU),
   UINTMAX_MAX / 659)
P (2, 66,
   (((((uintmax_t) 0x995eU << 28 | 0x1ca8dbfU)
      << 28 | 0xb5a3d31U)
     << 28 | 0x2fa30ccU)
    << 28 | 0x7d7b8bdU),
   UINTMAX_MAX / 661)
P (12, 60,
   (((((uintmax_t) 0x9f00U << 28 | 0x6160ff9U)
      << 28 | 0xe9f0061U)
     << 28 | 0x60ff9e9U)
    << 28 | 0xf006161U),
   UINTMAX_MAX / 673)
P (4, 62,
   (((((uintmax_t) 0xb33cU << 28 | 0xe15ee9bU)
      << 28 | 0x097416bU)
     << 28 | 0x03673b5U)
    << 28 | 0xe28152dU),
   UINTMAX_MAX / 677)
P (6, 60,
   (((((uintmax_t) 0xfa00U << 28 | 0xbfe802fU)
      << 28 | 0xfa00bfeU)
     << 28 | 0x802ffa0U)
    << 28 | 0x0bfe803U),
   UINTMAX_MAX / 683)
P (8, 60,
   (((((uintmax_t) 0x1c28U << 28 | 0x02f6bcfU)
      << 28 | 0x18d26e6U)
     << 28 | 0x6fe25c9U)
    << 28 | 0xe907c7bU),
   UINTMAX_MAX / 691)
P (10, 56,
   (((((uintmax_t) 0xcf6dU << 28 | 0xec4793eU)
      << 28 | 0x72aba3fU)
     << 28 | 0x8b236c7U)
    << 28 | 0x6528895U),
   UINTMAX_MAX / 701)
P (8, 52,
   (((((uintmax_t) 0x1e54U << 28 | 0x7da72d2U)
      << 28 | 0x24d44f6U)
     << 28 | 0xf923bf0U)
    << 28 | 0x1ce2c0dU),
   UINTMAX_MAX / 709)
P (10, 50,
   (((((uintmax_t) 0x7746U << 28 | 0xda9d5fcU)
      << 28 | 0x708306cU)
     << 28 | 0x3d3d98bU)
    << 28 | 0xed7c42fU),
   UINTMAX_MAX / 719)
P (8, 46,
   (((((uintmax_t) 0xcdffU << 28 | 0x4bb5591U)
      << 28 | 0x6e37a30U)
     << 28 | 0x981efcdU)
    << 28 | 0x4b010e7U),
   UINTMAX_MAX / 727)
P (6, 54,
   (((((uintmax_t) 0x2c01U << 28 | 0x65a1b3dU)
      << 28 | 0xd13356fU)
     << 28 | 0x691fc81U)
    << 28 | 0xebbe575U),
   UINTMAX_MAX / 733)
P (6, 58,
   (((((uintmax_t) 0xa802U << 28 | 0xc574bddU)
      << 28 | 0x5bccbb1U)
     << 28 | 0x0480ddbU)
    << 28 | 0x47b52cbU),
   UINTMAX_MAX / 739)
P (4, 66,
   (((((uintmax_t) 0x5411U << 28 | 0xeaa350fU)
      << 28 | 0x8134b74U)
     << 28 | 0xcd59ed6U)
    << 28 | 0x4f3f0d7U),
   UINTMAX_MAX / 743)
P (8, 60,
   (((((uintmax_t) 0xfceeU << 28 | 0x9d7c6bbU)
      << 28 | 0x7bbd301U)
     << 28 | 0x05cb813U)
    << 28 | 0x16d6c0fU),
   UINTMAX_MAX / 751)
P (6, 64,
   (((((uintmax_t) 0x4248U << 28 | 0x5eb0874U)
      << 28 | 0x553879bU)
     << 28 | 0xe64c6d9U)
    << 28 | 0x1c1195dU),
   UINTMAX_MAX / 757)
P (4, 62,
   (((((uintmax_t) 0xe060U << 28 | 0xe20f797U)
      << 28 | 0x0b19e71U)
     << 28 | 0xb3f945aU)
    << 28 | 0x27b1f49U),
   UINTMAX_MAX / 761)
P (8, 58,
   (((((uintmax_t) 0x782dU << 28 | 0x463deb5U)
      << 28 | 0xc369877U)
     << 28 | 0xd80d50eU)
    << 28 | 0x508fd01U),
   UINTMAX_MAX / 769)
P (4, 56,
   (((((uintmax_t) 0x4a2fU << 28 | 0x06f468aU)
      << 28 | 0x6e9cfa5U)
     << 28 | 0xeb778e1U)
    << 28 | 0x33551cdU),
   UINTMAX_MAX / 773)
P (14, 52,
   (((((uintmax_t) 0xda44U << 28 | 0x4f5ea87U)
      << 28 | 0xf831718U)
     << 28 | 0x657d3c2U)
    << 28 | 0xd8a3f1bU),
   UINTMAX_MAX / 787)
P (10, 56,
   (((((uintmax_t) 0xfb80U << 28 | 0xcd9225eU)
      << 28 | 0x6f2302eU)
     << 28 | 0x40e220cU)
    << 28 | 0x34ad735U),
   UINTMAX_MAX / 797)
P (12, 48,
   (((((uintmax_t) 0x1719U << 28 | 0xa1b36beU)
      << 28 | 0x7f357a7U)
     << 28 | 0x6593c70U)
    << 28 | 0xa714919U),
   UINTMAX_MAX / 809)
P (2, 48,
   (((((uintmax_t) 0x2867U << 28 | 0x894fdcaU)
      << 28 | 0x567da1eU)
     << 28 | 0xef45212U)
    << 28 | 0x4eea383U),
   UINTMAX_MAX / 811)
P (10, 42,
   (((((uintmax_t) 0x8932U << 28 | 0xd36914eU)
      << 28 | 0x43f9c38U)
     << 28 | 0x206dc24U)
    << 28 | 0x2ba771dU),
   UINTMAX_MAX / 821)
P (2, 54,
   (((((uintmax_t) 0xdeb7U << 28 | 0x8610cc0U)
      << 28 | 0xdafbf4cU)
     << 28 | 0xd4c3580U)
    << 28 | 0x7772287U),
   UINTMAX_MAX / 823)
P (4, 54,
   (((((uintmax_t) 0x8fa1U << 28 | 0xe560e3dU)
      << 28 | 0x4a9a283U)
     << 28 | 0xde917d5U)
    << 28 | 0xe69ddf3U),
   UINTMAX_MAX / 827)
P (2, 54,
   (((((uintmax_t) 0x6724U << 28 | 0x2159dccU)
      << 28 | 0xbcfd388U)
     << 28 | 0x2ef0403U)
    << 28 | 0xb4a6c15U),
   UINTMAX_MAX / 829)
P (10, 48,
   (((((uintmax_t) 0x5e96U << 28 | 0xbb58ca9U)
      << 28 | 0xa64b0f8U)
     << 28 | 0xfb6c51cU)
    << 28 | 0x606b677U),
   UINTMAX_MAX / 839)
P (14, 54,
   (((((uintmax_t) 0x2450U << 28 | 0x6e7171bU)
      << 28 | 0xe930eb4U)
     << 28 | 0xabaac44U)
    << 28 | 0x6d3e1fdU),
   UINTMAX_MAX / 853)
P (4, 54,
   (((((uintmax_t) 0x3743U << 28 | 0x3611535U)
      << 28 | 0x7861fa9U)
     << 28 | 0xf83bbe4U)
    << 28 | 0x84a14e9U),
   UINTMAX_MAX / 857)
P (2, 60,
   (((((uintmax_t) 0x232aU << 28 | 0x9df37baU)
      << 28 | 0xdbf080bU)
     << 28 | 0xebbc0d1U)
    << 28 | 0xce874d3U),
   UINTMAX_MAX / 859)
P (4, 66,
   (((((uintmax_t) 0x569eU << 28 | 0x67d2e92U)
      << 28 | 0x8a3bebdU)
     << 28 | 0x418eaf0U)
    << 28 | 0x473189fU),
   UINTMAX_MAX / 863)
P (14, 60,
   (((((uintmax_t) 0x7e1aU << 28 | 0x457923eU)
      << 28 | 0x77ae444U)
     << 28 | 0xe3af6f3U)
    << 28 | 0x72b7e65U),
   UINTMAX_MAX / 877)
P (4, 60,
   (((((uintmax_t) 0x9764U << 28 | 0x3fed672U)
      << 28 | 0x7cf2ec8U)
     << 28 | 0x7fdace4U)
    << 28 | 0xf9e5d91U),
   UINTMAX_MAX / 881)
P (2, 64,
   (((((uintmax_t) 0xea8bU << 28 | 0xbde5e83U)
      << 28 | 0x9fbf0ecU)
     << 28 | 0x93479c4U)
    << 28 | 0x46bd9bbU),
   UINTMAX_MAX / 883)
P (4, 66,
   (((((uintmax_t) 0x3d2fU << 28 | 0x9f06a35U)
      << 28 | 0xae9c6daU)
     << 28 | 0xc4d592eU)
    << 28 | 0x777c647U),
   UINTMAX_MAX / 887)
P (20, 60,
   (((((uintmax_t) 0x81d5U << 28 | 0xa9a1ba9U)
      << 28 | 0x11379a6U)
     << 28 | 0x3ea8c8fU)
    << 28 | 0x61f0c23U),
   UINTMAX_MAX / 907)
P (4, 60,
   (((((uintmax_t) 0x752eU << 28 | 0x5ddb77fU)
      << 28 | 0xdc07de4U)
     << 28 | 0x76062eaU)
    << 28 | 0x5cbbb6fU),
   UINTMAX_MAX / 911)
P (8, 58,
   (((((uintmax_t) 0x1abdU << 28 | 0xfafc60fU)
      << 28 | 0x0add2dfU)
     << 28 | 0x68761c6U)
    << 28 | 0x9daac27U),
   UINTMAX_MAX / 919)
P (10, 54,
   (((((uintmax_t) 0xac3aU << 28 | 0x6b786c0U)
      << 28 | 0x582e4b8U)
     << 28 | 0x13d7376U)
    << 28 | 0x37aa061U),
   UINTMAX_MAX / 929)
P (8, 54,
   (((((uintmax_t) 0x131fU << 28 | 0xf741d81U)
      << 28 | 0xc6a01a3U)
     << 28 | 0xa77aac1U)
    << 28 | 0xfb15099U),
   UINTMAX_MAX / 937)
P (4, 56,
   (((((uintmax_t) 0xc53cU << 28 | 0xaad918cU)
      << 28 | 0x1b34817U)
     << 28 | 0xf0c3e07U)
    << 28 | 0x12c5825U),
   UINTMAX_MAX / 941)
P (6, 62,
   (((((uintmax_t) 0xea1aU << 28 | 0x7df8f8bU)
      << 28 | 0x37f52fdU)
     << 28 | 0x912a70fU)
    << 28 | 0xf30637bU),
   UINTMAX_MAX / 947)
P (6, 60,
   (((((uintmax_t) 0xbb3bU << 28 | 0x5dc0113U)
      << 28 | 0x1288ffbU)
     << 28 | 0xb3b5dc0U)
    << 28 | 0x1131289U),
   UINTMAX_MAX / 953)
P (14, 52,
   (((((uintmax_t) 0x50beU << 28 | 0x9c31c53U)
      << 28 | 0xa81b885U)
     << 28 | 0x6d560a0U)
    << 28 | 0xf5acdf7U),
   UINTMAX_MAX / 967)
P (4, 50,
   (((((uintmax_t) 0x6580U << 28 | 0xec3a008U)
      << 28 | 0x6fc9296U)
     << 28 | 0x472f314U)
    << 28 | 0xd3f89e3U),
   UINTMAX_MAX / 971)
P (6, 54,
   (((((uintmax_t) 0x1108U << 28 | 0x1f71752U)
      << 28 | 0x03ab1a7U)
     << 28 | 0x6f5c7edU)
    << 28 | 0x2253531U),
   UINTMAX_MAX / 977)
P (6, 50,
   (((((uintmax_t) 0xb81fU << 28 | 0x4053563U)
      << 28 | 0x3908981U)
     << 28 | 0x6eae7c7U)
    << 28 | 0xbf69fe7U),
   UINTMAX_MAX / 983)
P (8, 48,
   (((((uintmax_t) 0x9c8bU << 28 | 0x7ed668eU)
      << 28 | 0x14263b6U)
     << 28 | 0xa2bea4cU)
    << 28 | 0xfb1781fU),
   UINTMAX_MAX / 991)
P (6, 52,
   (((((uintmax_t) 0x0291U << 28 | 0x54fdb06U)
      << 28 | 0x6b547a3U)
     << 28 | 0x900c533U)
    << 28 | 0x18e81edU),
   UINTMAX_MAX / 997)
P (12, 42,
   (((((uintmax_t) 0x2240U << 28 | 0x71aa3e6U)
      << 28 | 0xa0db360U)
     << 28 | 0xaa7f5d9U)
    << 28 | 0xf148d11U),
   UINTMAX_MAX / 1009)
P (4, 48,
   (((((uintmax_t) 0x02c7U << 28 | 0xa505cffU)
      << 28 | 0xbf4e16bU)
     << 28 | 0xe8c0102U)
    << 28 | 0xc7a505dU),
   UINTMAX_MAX / 1013)
P (6, 44,
   (((((uintmax_t) 0xcafdU << 28 | 0xbd2c779U)
      << 28 | 0x57ad98fU)
     << 28 | 0xf3f0ed2U)
    << 28 | 0x8728f33U),
   UINTMAX_MAX / 1019)
P (2, 48,
   (((((uintmax_t) 0x513cU << 28 | 0xedb245bU)
      << 28 | 0x4473568U)
     << 28 | 0x0e0a87eU)
    << 28 | 0x5ec7155U),
   UINTMAX_MAX / 1021)
P (10, 56,
   (((((uintmax_t) 0x2e6eU << 28 | 0xbe33267U)
      << 28 | 0xca5ddbbU)
     << 28 | 0xf70fa49U)
    << 28 | 0xfe829b7U),
   UINTMAX_MAX / 1031)
P (2, 58,
   (((((uintmax_t) 0x007eU << 28 | 0xe2825abU)
      << 28 | 0x3eb2ed6U)
     << 28 | 0x9d1e7b6U)
    << 28 | 0xa50ca39U),
   UINTMAX_MAX / 1033)
P (6, 54,
   (((((uintmax_t) 0x2f8dU << 28 | 0xacb84cdU)
      << 28 | 0xfb90a1aU)
     << 28 | 0x1e0f46bU)
    << 28 | 0x6d26aefU),
   UINTMAX_MAX / 1039)
P (10, 48,
   (((((uintmax_t) 0x01f3U << 28 | 0xcc435b0U)
      << 28 | 0x713c474U)
     << 28 | 0x29f9a7aU)
    << 28 | 0x8251829U),
   UINTMAX_MAX / 1049)
P (2, 52,
   (((((uintmax_t) 0x8c0eU << 28 | 0x9d59e14U)
      << 28 | 0xf29a6d9U)
     << 28 | 0xc2219d1U)
    << 28 | 0xb863613U),
   UINTMAX_MAX / 1051)
P (10, 48,
   (((((uintmax_t) 0x6e81U << 28 | 0xcf42d5cU)
      << 28 | 0x6932e91U)
     << 28 | 0x406c182U)
    << 28 | 0x0d077adU),
   UINTMAX_MAX / 1061)
P (2, 54,
   (((((uintmax_t) 0x9c4cU << 28 | 0x1a02688U)
      << 28 | 0x4efdd52U)
     << 28 | 0x1f4ec02U)
    << 28 | 0xe3d2b97U),
   UINTMAX_MAX / 1063)
P (6, 54,
   (((((uintmax_t) 0x7bcfU << 28 | 0x2599067U)
      << 28 | 0x74255bbU)
     << 28 | 0x8283b63U)
    << 28 | 0xdc8eba5U),
   UINTMAX_MAX / 1069)
P (18, 42,
   (((((uintmax_t) 0x46a7U << 28 | 0x3667275U)
      << 28 | 0x48c5d43U)
     << 28 | 0x1eda153U)
    << 28 | 0x229ebbfU),
   UINTMAX_MAX / 1087)
P (4, 60,
   (((((uintmax_t) 0xe720U << 28 | 0x9daecfeU)
      << 28 | 0x5b832afU)
     << 28 | 0x0bf78d7U)
    << 28 | 0xe01686bU),
   UINTMAX_MAX / 1091)
P (2, 60,
   (((((uintmax_t) 0x194bU << 28 | 0xa6ff4c1U)
      << 28 | 0xeeaafa9U)
     << 28 | 0xced0742U)
    << 28 | 0xc086e8dU),
   UINTMAX_MAX / 1093)
P (4, 66,
   (((((uintmax_t) 0x777bU << 28 | 0x730c5e4U)
      << 28 | 0x768c7c2U)
     << 28 | 0x6458ad9U)
    << 28 | 0xf632df9U),
   UINTMAX_MAX / 1097)
P (6, 68,
   (((((uintmax_t) 0x2aefU << 28 | 0xfc49577U)
      << 28 | 0xfe24abbU)
     << 28 | 0xff1255dU)
    << 28 | 0xff892afU),
   UINTMAX_MAX / 1103)
P (6, 72,
   (((((uintmax_t) 0xf1b0U << 28 | 0x213da24U)
      << 28 | 0x78f59cbU)
     << 28 | 0xd49a333U)
    << 28 | 0xf04d8fdU),
   UINTMAX_MAX / 1109)
P (8, 70,
   (((((uintmax_t) 0x8822U << 28 | 0xd60f205U)
      << 28 | 0x0ac58ecU)
     << 28 | 0x84ed6f9U)
    << 28 | 0xcfdeff5U),
   UINTMAX_MAX / 1117)
P (6, 70,
   (((((uintmax_t) 0x3606U << 28 | 0xd6bd351U)
      << 28 | 0xd682d97U)
     << 28 | 0x980cc40U)
    << 28 | 0xbda9d4bU),
   UINTMAX_MAX / 1123)
P (6, 72,
   (((((uintmax_t) 0x0122U << 28 | 0x3d38ea0U)
      << 28 | 0x15c4977U)
     << 28 | 0x7f34d52U)
    << 28 | 0x4f5cbd9U),
   UINTMAX_MAX / 1129)
P (22, 62,
   (((((uintmax_t) 0x78feU << 28 | 0x716e8a5U)
      << 28 | 0x7a1b227U)
     << 28 | 0x97051d9U)
    << 28 | 0x4cbbb7fU),
   UINTMAX_MAX / 1151)
P (2, 64,
   (((((uintmax_t) 0xd6ecU << 28 | 0xaef5908U)
      << 28 | 0xa8be0eaU)
     << 28 | 0x769051bU)
    << 28 | 0x4f43b81U),
   UINTMAX_MAX / 1153)
P (10, 60,
   (((((uintmax_t) 0x7867U << 28 | 0xe595e6eU)
      << 28 | 0x801c2ceU)
     << 28 | 0x7910f30U)
    << 28 | 0x34d4323U),
   UINTMAX_MAX / 1163)
P (8, 58,
   (((((uintmax_t) 0xa705U << 28 | 0xe713e4eU)
      << 28 | 0x43c5692U)
     << 28 | 0x791d137U)
    << 28 | 0x4f5b99bU),
   UINTMAX_MAX / 1171)
P (10, 50,
   (((((uintmax_t) 0x92c0U << 28 | 0x0ddf7c3U)
      << 28 | 0x4e40989U)
     << 28 | 0xa5645ccU)
    << 28 | 0x68ea1b5U),
   UINTMAX_MAX / 1181)
P (6, 50,
   (((((uintmax_t) 0xab06U << 28 | 0xaf8e205U)
      << 28 | 0x9b7f75fU)
     << 28 | 0x8aacf79U)
    << 28 | 0x6c0cf0bU),
   UINTMAX_MAX / 1187)
P (6, 56,
   (((((uintmax_t) 0xe187U << 28 | 0x673725fU)
      << 28 | 0xb4774f2U)
     << 28 | 0xe90a15eU)
    << 28 | 0x33edf99U),
   UINTMAX_MAX / 1193)
P (8, 58,
   (((((uintmax_t) 0x57d1U << 28 | 0xf5579b6U)
      << 28 | 0x3f8538eU)
     << 28 | 0x99e5febU)
    << 28 | 0x897c451U),
   UINTMAX_MAX / 1201)
P (12, 64,
   (((((uintmax_t) 0x5f64U << 28 | 0xab5ec29U)
      << 28 | 0x5d7e6acU)
     << 28 | 0xa2eda38U)
    << 28 | 0xfb91695U),
   UINTMAX_MAX / 1213)
P (4, 62,
   (((((uintmax_t) 0x48c8U << 28 | 0x41a1574U)
      << 28 | 0xbf0035dU)
     << 28 | 0x9b737beU)
    << 28 | 0x5ea8b41U),
   UINTMAX_MAX / 1217)
P (6, 60,
   (((((uintmax_t) 0x348aU << 28 | 0x26ef0b8U)
      << 28 | 0x33e964aU)
     << 28 | 0xefe1db9U)
    << 28 | 0x3fd7cf7U),
   UINTMAX_MAX / 1223)
P (6, 60,
   (((((uintmax_t) 0x5247U << 28 | 0x3d081faU)
      << 28 | 0x958f1a0U)
     << 28 | 0x994ef20U)
    << 28 | 0xb3f8805U),
   UINTMAX_MAX / 1229)
P (2, 60,
   (((((uintmax_t) 0x0ec3U << 28 | 0xe6367c5U)
      << 28 | 0xc55ae10U)
     << 28 | 0x3890bdaU)
    << 28 | 0x912822fU),
   UINTMAX_MAX / 1231)
P (6, 60,
   (((((uintmax_t) 0xb57fU << 28 | 0x46921bbU)
      << 28 | 0xb4ab5b4U)
     << 28 | 0x41659d1U)
    << 28 | 0x3a9147dU),
   UINTMAX_MAX / 1237)
P (12, 52,
   (((((uintmax_t) 0xb2eeU << 28 | 0xfcecf03U)
      << 28 | 0x7c00d1eU)
     << 28 | 0x2134440U)
    << 28 | 0xc4c3f21U),
   UINTMAX_MAX / 1249)
P (10, 44,
   (((((uintmax_t) 0xed4bU << 28 | 0x07ee1b3U)
      << 28 | 0xf3ccc26U)
     << 28 | 0x3a27727U)
    << 28 | 0xa6883c3U),
   UINTMAX_MAX / 1259)
P (18, 30,
   (((((uintmax_t) 0x435bU << 28 | 0x9d5e6bdU)
      << 28 | 0xa4fc978U)
     << 28 | 0xe221472U)
    << 28 | 0xab33855U),
   UINTMAX_MAX / 1277)
P (2, 40,
   (((((uintmax_t) 0x6013U << 28 | 0x370b023U)
      << 28 | 0x3a3ed95U)
     << 28 | 0xeac88e8U)
    << 28 | 0x2e6faffU),
   UINTMAX_MAX / 1279)
P (4, 38,
   (((((uintmax_t) 0x3447U << 28 | 0x089473bU)
      << 28 | 0xa900ff6U)
     << 28 | 0x6c25831U)
    << 28 | 0x7be8dabU),
   UINTMAX_MAX / 1283)
P (6, 38,
   (((((uintmax_t) 0x0f7dU << 28 | 0xb74fa3dU)
      << 28 | 0x912de09U)
     << 28 | 0xee202c7U)
    << 28 | 0xcb91939U),
   UINTMAX_MAX / 1289)
P (2, 70,
   (((((uintmax_t) 0x5316U << 28 | 0x02c6b14U)
      << 28 | 0x6caa88dU)
     << 28 | 0x2fca104U)
    << 28 | 0x2a09ea3U),
   UINTMAX_MAX / 1291)
P (6, 70,
   (((((uintmax_t) 0x2128U << 28 | 0xdb7c26aU)
      << 28 | 0xfaabb82U)
     << 28 | 0x779c856U)
    << 28 | 0xd8b8bf1U),
   UINTMAX_MAX / 1297)
P (4, 72,
   (((((uintmax_t) 0xb01cU << 28 | 0x55cadf2U)
      << 28 | 0x39d9d38U)
     << 28 | 0x79361cbU)
    << 28 | 0xa8a223dU),
   UINTMAX_MAX / 1301)
P (2, 78,
   (((((uintmax_t) 0x3d4cU << 28 | 0x6d3cb58U)
      << 28 | 0x9b9a9f2U)
     << 28 | 0x3f43639U)
    << 28 | 0xc3182a7U),
   UINTMAX_MAX / 1303)
P (4, 92,
   (((((uintmax_t) 0x0bc0U << 28 | 0x89e42fcU)
      << 28 | 0xab94aa0U)
     << 28 | 0x3868fc4U)
    << 28 | 0x74bcd13U),
   UINTMAX_MAX / 1307)
P (12, 90,
   (((((uintmax_t) 0x34fcU << 28 | 0x4ff6af1U)
      << 28 | 0x0e2b165U)
     << 28 | 0x1e78b8cU)
    << 28 | 0x5311a97U),
   UINTMAX_MAX / 1319)
P (2, 102,
   (((((uintmax_t) 0x18ffU << 28 | 0xce639c0U)
      << 28 | 0x0c6718fU)
     << 28 | 0xfce639cU)
    << 28 | 0x00c6719U),
   UINTMAX_MAX / 1321)
P (6, 100,
   (((((uintmax_t) 0x9b4cU << 28 | 0x33b39aeU)
      << 28 | 0x96dc4f7U)
     << 28 | 0xb460754U)
    << 28 | 0xb0b61cfU),
   UINTMAX_MAX / 1327)
P (34, 68,
   (((((uintmax_t) 0xbbe8U << 28 | 0xad0c9a3U)
      << 28 | 0xd51d27bU)
     << 28 | 0x03f3359U)
    << 28 | 0xb8e63b1U),
   UINTMAX_MAX / 1361)
P (6, 66,
   (((((uintmax_t) 0xa28dU << 28 | 0x33dfca1U)
      << 28 | 0x0dabba5U)
     << 28 | 0x5c53260U)
    << 28 | 0x41eb667U),
   UINTMAX_MAX / 1367)
P (6, 66,
   (((((uintmax_t) 0x677bU << 28 | 0x3ed5acdU)
      << 28 | 0x78a2964U)
     << 28 | 0x7f88ab8U)
    << 28 | 0x96a76f5U),
   UINTMAX_MAX / 1373)
P (8, 66,
   (((((uintmax_t) 0xf4e0U << 28 | 0xac06ac6U)
      << 28 | 0x595988fU)
     << 28 | 0xd971434U)
    << 28 | 0xa55a46dU),
   UINTMAX_MAX / 1381)
P (18, 52,
   (((((uintmax_t) 0x3ba7U << 28 | 0x6f12d90U)
      << 28 | 0x609e19fU)
     << 28 | 0xbf96995U)
    << 28 | 0x8046447U),
   UINTMAX_MAX / 1399)
P (10, 44,
   (((((uintmax_t) 0x3d69U << 28 | 0x32b0f71U)
      << 28 | 0x8e43399U)
     << 28 | 0x86feba6U)
    << 28 | 0x9be3a81U),
   UINTMAX_MAX / 1409)
P (14, 36,
   (((((uintmax_t) 0xb7adU << 28 | 0xf701426U)
      << 28 | 0x239eda6U)
     << 28 | 0x68b3e6dU)
    << 28 | 0x053796fU),
   UINTMAX_MAX / 1423)
P (4, 44,
   (((((uintmax_t) 0xd0d1U << 28 | 0x893d2caU)
      << 28 | 0xb80fc97U)
     << 28 | 0x694e658U)
    << 28 | 0x9f4e09bU),
   UINTMAX_MAX / 1427)
P (2, 52,
   (((((uintmax_t) 0xc00bU << 28 | 0x7721dbcU)
      << 28 | 0xffd2237U)
     << 28 | 0x890c00bU)
    << 28 | 0x7721dbdU),
   UINTMAX_MAX / 1429)
P (4, 50,
   (((((uintmax_t) 0xe9d9U << 28 | 0x0e1cf0dU)
      << 28 | 0x0a8a45aU)
     << 28 | 0xc094a23U)
    << 28 | 0x5f37ea9U),
   UINTMAX_MAX / 1433)
P (6, 48,
   (((((uintmax_t) 0x8489U << 28 | 0x56fe661U)
      << 28 | 0xd881831U)
     << 28 | 0xcff775fU)
    << 28 | 0x2d5d65fU),
   UINTMAX_MAX / 1439)
P (8, 42,
   (((((uintmax_t) 0xfd85U << 28 | 0xed3f28dU)
      << 28 | 0xe356dddU)
     << 28 | 0xad8e6b3U)
    << 28 | 0x6505217U),
   UINTMAX_MAX / 1447)
P (4, 42,
   (((((uintmax_t) 0x0a68U << 28 | 0xcca8aacU)
      << 28 | 0x8c7035aU)
     << 28 | 0x27df897U)
    << 28 | 0x062cd03U),
   UINTMAX_MAX / 1451)
P (2, 46,
   (((((uintmax_t) 0x57eaU << 28 | 0xdb877ceU)
      << 28 | 0xaae6ce2U)
     << 28 | 0x396fe0fU)
    << 28 | 0xdb5a625U),
   UINTMAX_MAX / 1453)
P (6, 52,
   (((((uintmax_t) 0x1c12U << 28 | 0xf330f43U)
      << 28 | 0xe76f6b3U)
     << 28 | 0x52a4957U)
    << 28 | 0xe82317bU),
   UINTMAX_MAX / 1459)
P (12, 52,
   (((((uintmax_t) 0x472dU << 28 | 0xc52d6c1U)
      << 28 | 0x2cb9dd8U)
     << 28 | 0xab3f2c6U)
    << 28 | 0x0c2ea3fU),
   UINTMAX_MAX / 1471)
P (10, 50,
   (((((uintmax_t) 0xda51U << 28 | 0x3e0e2c9U)
      << 28 | 0x8ce0b68U)
     << 28 | 0x93f702fU)
    << 28 | 0x0452479U),
   UINTMAX_MAX / 1481)
P (2, 60,
   (((((uintmax_t) 0x442fU << 28 | 0xa4dae2dU)
      << 28 | 0x3a2c896U)
     << 28 | 0x86fdc18U)
    << 28 | 0x2acf7e3U),
   UINTMAX_MAX / 1483)
P (4, 62,
   (((((uintmax_t) 0x091fU << 28 | 0xd96fbb2U)
      << 28 | 0x2f2be68U)
     << 28 | 0x5403717U)
    << 28 | 0x3dce12fU),
   UINTMAX_MAX / 1487)
P (2, 64,
   (((((uintmax_t) 0x3accU << 28 | 0x97fbdfaU)
      << 28 | 0xd798d7fU)
     << 28 | 0x0ded168U)
    << 28 | 0x5c27331U),
   UINTMAX_MAX / 1489)
P (4, 66,
   (((((uintmax_t) 0x4d54U << 28 | 0xe047548U)
      << 28 | 0x87cd3eeU)
     << 28 | 0xda72e1fU)
    << 28 | 0xe490b7dU),
   UINTMAX_MAX / 1493)
P (6, 68,
   (((((uintmax_t) 0x7e8cU << 28 | 0x61afbbbU)
      << 28 | 0x013209eU)
     << 28 | 0x7bfc959U)
    << 28 | 0xa8e6e53U),
   UINTMAX_MAX / 1499)
P (12, 60,
   (((((uintmax_t) 0xc4b3U << 28 | 0x96f4fccU)
      << 28 | 0x7ebab49U)
     << 28 | 0xb314d6dU)
    << 28 | 0x4753dd7U),
   UINTMAX_MAX / 1511)
P (12, 56,
   (((((uintmax_t) 0x9eadU << 28 | 0x21c933fU)
      << 28 | 0x089292eU)
     << 28 | 0x8f8c5acU)
    << 28 | 0x4aa1b3bU),
   UINTMAX_MAX / 1523)
P (8, 52,
   (((((uintmax_t) 0x0584U << 28 | 0x992a4deU)
      << 28 | 0xb99aab8U)
     << 28 | 0xef72348U)
    << 28 | 0x1163d33U),
   UINTMAX_MAX / 1531)
P (12, 54,
   (((((uintmax_t) 0x8b08U << 28 | 0x7620d9aU)
      << 28 | 0xcb6806aU)
     << 28 | 0x2ec96a5U)
    << 28 | 0x94287b7U),
   UINTMAX_MAX / 1543)
P (6, 52,
   (((((uintmax_t) 0xc108U << 28 | 0x6dbce6bU)
      << 28 | 0x6c94bdbU)
     << 28 | 0xa41c6d1U)
    << 28 | 0x3aab8c5U),
   UINTMAX_MAX / 1549)
P (4, 54,
   (((((uintmax_t) 0xe478U << 28 | 0xaa1e005U)
      << 28 | 0x46633c2U)
     << 28 | 0xadbe648U)
    << 28 | 0xdc3aaf1U),
   UINTMAX_MAX / 1553)
P (6, 50,
   (((((uintmax_t) 0x5cf1U << 28 | 0x0e9d4faU)
      << 28 | 0x40b2a87U)
     << 28 | 0xa2bade5U)
    << 28 | 0x65f91a7U),
   UINTMAX_MAX / 1559)
P (8, 46,
   (((((uintmax_t) 0x9ecbU << 28 | 0x8ef2c45U)
      << 28 | 0xec11a4dU)
     << 28 | 0x6fe8798U)
    << 28 | 0xc01f5dfU),
   UINTMAX_MAX / 1567)
P (4, 48,
   (((((uintmax_t) 0xfb99U << 28 | 0xaa49543U)
      << 28 | 0xf39d937U)
     << 28 | 0x91310c8U)
    << 28 | 0xc23d98bU),
   UINTMAX_MAX / 1571)
P (8, 42,
   (((((uintmax_t) 0x7abbU << 28 | 0x187b379U)
      << 28 | 0xc2112f8U)
     << 28 | 0x0e446b0U)
    << 28 | 0x1228883U),
   UINTMAX_MAX / 1579)
P (4, 44,
   (((((uintmax_t) 0x3cceU << 28 | 0x5a3d212U)
      << 28 | 0x6f95e9aU)
     << 28 | 0xed1436fU)
    << 28 | 0xbf500cfU),
   UINTMAX_MAX / 1583)
P (14, 40,
   (((((uintmax_t) 0xc6eeU << 28 | 0xd90c05cU)
      << 28 | 0x5547a78U)
     << 28 | 0x39b54ccU)
    << 28 | 0x8b24115U),
   UINTMAX_MAX / 1597)
P (4, 56,
   (((((uintmax_t) 0x8798U << 28 | 0x627f99aU)
      << 28 | 0x9f948c1U)
     << 28 | 0x28c646aU)
    << 28 | 0xd0309c1U),
   UINTMAX_MAX / 1601)
P (6, 56,
   (((((uintmax_t) 0x5233U << 28 | 0x4bab403U)
      << 28 | 0x2fa1b14U)
     << 28 | 0xde63162U)
    << 28 | 0x4a3c377U),
   UINTMAX_MAX / 1607)
P (2, 58,
   (((((uintmax_t) 0x0e51U << 28 | 0xc7ad43fU)
      << 28 | 0x016e93fU)
     << 28 | 0x7b9fe68U)
    << 28 | 0xb0ecbf9U),
   UINTMAX_MAX / 1609)
P (4, 56,
   (((((uintmax_t) 0x00a2U << 28 | 0x84ffd75U)
      << 28 | 0xec00a28U)
     << 28 | 0x4ffd75eU)
    << 28 | 0xc00a285U),
   UINTMAX_MAX / 1613)
P (6, 74,
   (((((uintmax_t) 0xe72cU << 28 | 0xbfa4ebeU)
      << 28 | 0xb20bb37U)
     << 28 | 0x803cb80U)
    << 28 | 0xdea2ddbU),
   UINTMAX_MAX / 1619)
P (2, 76,
   (((((uintmax_t) 0x22beU << 28 | 0x75d04e5U)
      << 28 | 0x4f6ff86U)
     << 28 | 0xb63f7c9U)
    << 28 | 0xac4c6fdU),
   UINTMAX_MAX / 1621)
P (6, 72,
   (((((uintmax_t) 0x84f4U << 28 | 0xd419cdfU)
      << 28 | 0x6dfbe8bU)
     << 28 | 0x6851d1bU)
    << 28 | 0xd99b9d3U),
   UINTMAX_MAX / 1627)
P (10, 72,
   (((((uintmax_t) 0xe83aU << 28 | 0xccdcd04U)
      << 28 | 0xd90f7b6U)
     << 28 | 0x2fda77cU)
    << 28 | 0xa343b6dU),
   UINTMAX_MAX / 1637)
P (20, 64,
   (((((uintmax_t) 0x9e34U << 28 | 0x383c8ffU)
      << 28 | 0xd872f1fU)
     << 28 | 0x0dc009eU)
    << 28 | 0x34383c9U),
   UINTMAX_MAX / 1657)
P (6, 60,
   (((((uintmax_t) 0x2e7dU << 28 | 0x4e5ad2eU)
      << 28 | 0x55e5d49U)
     << 28 | 0x6dc21ddU)
    << 28 | 0xd35b97fU),
   UINTMAX_MAX / 1663)
P (4, 66,
   (((((uintmax_t) 0xe596U << 28 | 0x098573aU)
      << 28 | 0x33e80b0U)
     << 28 | 0xe96ce17U)
    << 28 | 0x090f82bU),
   UINTMAX_MAX / 1667)
P (2, 72,
   (((((uintmax_t) 0x7181U << 28 | 0x4dc42e0U)
      << 28 | 0x3fceeaaU)
     << 28 | 0xdf05acdU)
    << 28 | 0xd7d024dU),
   UINTMAX_MAX / 1669)
P (24, 54,
   (((((uintmax_t) 0xa4abU << 28 | 0x2bb32f5U)
      << 28 | 0x43975cbU)
     << 28 | 0x1381967U)
    << 28 | 0x46eafb5U),
   UINTMAX_MAX / 1693)
P (4, 56,
   (((((uintmax_t) 0xa2ecU << 28 | 0x3cf1f87U)
      << 28 | 0x5102434U)
     << 28 | 0x7f52373U)
    << 28 | 0x6755d61U),
   UINTMAX_MAX / 1697)
P (2, 60,
   (((((uintmax_t) 0x6ff3U << 28 | 0xf223422U)
      << 28 | 0x5ab51d1U)
     << 28 | 0x4a48a05U)
    << 28 | 0x1f7dd0bU),
   UINTMAX_MAX / 1699)
P (10, 68,
   (((((uintmax_t) 0x6c00U << 28 | 0x9963e9dU)
      << 28 | 0x48f3447U)
     << 28 | 0x4d71b1cU)
    << 28 | 0xe914d25U),
   UINTMAX_MAX / 1709)
P (12, 62,
   (((((uintmax_t) 0x894cU << 28 | 0x02f99a8U)
      << 28 | 0xd502d38U)
     << 28 | 0x6063f5eU)
    << 28 | 0x28c1f89U),
   UINTMAX_MAX / 1721)
P (2, 64,
   (((((uintmax_t) 0xc8e0U << 28 | 0xa6684d4U)
      << 28 | 0x2b6281dU)
     << 28 | 0xb7325e3U)
    << 28 | 0x2d04e73U),
   UINTMAX_MAX / 1723)
P (10, 56,
   (((((uintmax_t) 0xf8c2U << 28 | 0xfdc8c0aU)
      << 28 | 0x0b85afeU)
     << 28 | 0xf748d38U)
    << 28 | 0x93b880dU),
   UINTMAX_MAX / 1733)
P (8, 60,
   (((((uintmax_t) 0xd0a7U << 28 | 0x0a25594U)
      << 28 | 0x123bb2fU)
     << 28 | 0x3351506U)
    << 28 | 0xe935605U),
   UINTMAX_MAX / 1741)
P (6, 64,
   (((((uintmax_t) 0xdb5dU << 28 | 0xa31878bU)
      << 28 | 0xf158a7aU)
     << 28 | 0x3637fa2U)
    << 28 | 0x376415bU),
   UINTMAX_MAX / 1747)
P (6, 70,
   (((((uintmax_t) 0x75b4U << 28 | 0x5a8abbcU)
      << 28 | 0xd2e004aU)
     << 28 | 0xc525d2bU)
    << 28 | 0xaa21969U),
   UINTMAX_MAX / 1753)
P (6, 72,
   (((((uintmax_t) 0x7e53U << 28 | 0x89d2e22U)
      << 28 | 0xa34af3aU)
     << 28 | 0x11c16b4U)
    << 28 | 0x2cd351fU),
   UINTMAX_MAX / 1759)
P (18, 70,
   (((((uintmax_t) 0xeaf7U << 28 | 0x801270aU)
      << 28 | 0x843ff6cU)
     << 28 | 0x7abde00U)
    << 28 | 0x49c2a11U),
   UINTMAX_MAX / 1777)
P (6, 78,
   (((((uintmax_t) 0x1ad9U << 28 | 0x60a0cecU)
      << 28 | 0x0ae9754U)
     << 28 | 0xdad0303U)
    << 28 | 0xe069ac7U),
   UINTMAX_MAX / 1783)
P (4, 80,
   (((((uintmax_t) 0x082aU << 28 | 0x676e737U)
      << 28 | 0x70be3ebU)
     << 28 | 0xf1ac9fdU)
    << 28 | 0xfe91433U),
   UINTMAX_MAX / 1787)
P (2, 82,
   (((((uintmax_t) 0x50b4U << 28 | 0xdfcda14U)
      << 28 | 0x51d9efaU)
     << 28 | 0xfdda823U)
    << 28 | 0x7cec655U),
   UINTMAX_MAX / 1789)
P (12, 72,
   (((((uintmax_t) 0x1ffbU << 28 | 0x738ffdbU)
      << 28 | 0x9c7fedcU)
     << 28 | 0xe3ff6e7U)
    << 28 | 0x1ffb739U),
   UINTMAX_MAX / 1801)
P (10, 66,
   (((((uintmax_t) 0xa660U << 28 | 0xf8ca6cdU)
      << 28 | 0x88f9ebeU)
     << 28 | 0xd5737d6U)
    << 28 | 0x286db1bU),
   UINTMAX_MAX / 1811)
P (12, 56,
   (((((uintmax_t) 0xed52U << 28 | 0xb6467eaU)
      << 28 | 0xa7abbe4U)
     << 28 | 0x79e431fU)
    << 28 | 0xe08b4dfU),
   UINTMAX_MAX / 1823)
P (8, 58,
   (((((uintmax_t) 0xdaf2U << 28 | 0xff4d09aU)
      << 28 | 0x5ae119dU)
     << 28 | 0xd9b0dd7U)
    << 28 | 0x742f897U),
   UINTMAX_MAX / 1831)
P (16, 54,
   (((((uintmax_t) 0x6054U << 28 | 0x454d33bU)
      << 28 | 0x2efc88fU)
     << 28 | 0x09d7402U)
    << 28 | 0xc5a5e87U),
   UINTMAX_MAX / 1847)
P (14, 46,
   (((((uintmax_t) 0xf545U << 28 | 0x31625b1U)
      << 28 | 0x0a51292U)
     << 28 | 0x16d5c4dU)
    << 28 | 0x958738dU),
   UINTMAX_MAX / 1861)
P (6, 46,
   (((((uintmax_t) 0x6df8U << 28 | 0x0c1100aU)
      << 28 | 0xf82f2b3U)
     << 28 | 0x139ba11U)
    << 28 | 0xd34ca63U),
   UINTMAX_MAX / 1867)
P (4, 60,
   (((((uintmax_t) 0xaf8bU << 28 | 0xf8e2952U)
      << 28 | 0x3b61d47U)
     << 28 | 0xd54f7edU)
    << 28 | 0x644afafU),
   UINTMAX_MAX / 1871)
P (2, 60,
   (((((uintmax_t) 0x4d5cU << 28 | 0x4227171U)
      << 28 | 0x9491f92U)
     << 28 | 0xa81d85cU)
    << 28 | 0xf11a1b1U),
   UINTMAX_MAX / 1873)
P (4, 72,
   (((((uintmax_t) 0xf78bU << 28 | 0x4082eeaU)
      << 28 | 0xdc21475U)
     << 28 | 0x4b26533U)
    << 28 | 0x253bdfdU),
   UINTMAX_MAX / 1877)
P (2, 72,
   (((((uintmax_t) 0xf354U << 28 | 0x558f76aU)
      << 28 | 0xad92bbbU)
     << 28 | 0xe0efc98U)
    << 28 | 0x0bfd467U),
   UINTMAX_MAX / 1879)
P (10, 84,
   (((((uintmax_t) 0x0ab4U << 28 | 0xc91d231U)
      << 28 | 0x99d11c0U)
     << 28 | 0xd8d594fU)
    << 28 | 0x024dca1U),
   UINTMAX_MAX / 1889)
P (12, 78,
   (((((uintmax_t) 0x1b56U << 28 | 0x52256feU)
      << 28 | 0x84c7d82U)
     << 28 | 0x38d43bcU)
    << 28 | 0xaac1a65U),
   UINTMAX_MAX / 1901)
P (6, 80,
   (((((uintmax_t) 0xaca2U << 28 | 0xb39dbc1U)
      << 28 | 0x2cb3e27U)
     << 28 | 0x779c1faU)
    << 28 | 0xe6175bbU),
   UINTMAX_MAX / 1907)
P (6, 80,
   (((((uintmax_t) 0x3856U << 28 | 0xb755c78U)
      << 28 | 0x7068ea7U)
     << 28 | 0x46ca9afU)
    << 28 | 0x708b2c9U),
   UINTMAX_MAX / 1913)
P (18, 66,
   (((((uintmax_t) 0x052bU << 28 | 0x9de5385U)
      << 28 | 0x8076c93U)
     << 28 | 0xf3cd9f3U)
    << 28 | 0x89be823U),
   UINTMAX_MAX / 1931)
P (2, 66,
   (((((uintmax_t) 0x820dU << 28 | 0x822f698U)
      << 28 | 0xd4f545cU)
     << 28 | 0xb4a4c04U)
    << 28 | 0xc489345U),
   UINTMAX_MAX / 1933)
P (16, 54,
   (((((uintmax_t) 0xcd09U << 28 | 0x536828fU)
      << 28 | 0xb23dbbfU)
     << 28 | 0x6047743U)
    << 28 | 0xe85b6b5U),
   UINTMAX_MAX / 1949)
P (2, 60,
   (((((uintmax_t) 0x8486U << 28 | 0xe386c1eU)
      << 28 | 0xf778961U)
     << 28 | 0xc147831U)
    << 28 | 0x563545fU),
   UINTMAX_MAX / 1951)
P (22, 44,
   (((((uintmax_t) 0xec68U << 28 | 0x5200c74U)
      << 28 | 0xc6c78edU)
     << 28 | 0xb47c0aeU)
    << 28 | 0x62dee9dU),
   UINTMAX_MAX / 1973)
P (6, 48,
   (((((uintmax_t) 0xd8acU << 28 | 0xd298624U)
      << 28 | 0xff1830aU)
     << 28 | 0x3824386U)
    << 28 | 0x673a573U),
   UINTMAX_MAX / 1979)
P (8, 42,
   (((((uintmax_t) 0x03ddU << 28 | 0x78b87ecU)
      << 28 | 0x6aad6a4U)
     << 28 | 0xa77d19eU)
    << 28 | 0x575a0ebU),
   UINTMAX_MAX / 1987)
P (6, 46,
   (((((uintmax_t) 0x8950U << 28 | 0x062a636U)
      << 28 | 0xb8325a2U)
     << 28 | 0xbee045eU)
    << 28 | 0x066c279U),
   UINTMAX_MAX / 1993)
P (4, 56,
   (((((uintmax_t) 0xa9daU << 28 | 0xd301275U)
      << 28 | 0xae369c2U)
     << 28 | 0x3618de8U)
    << 28 | 0xab43d05U),
   UINTMAX_MAX / 1997)
P (2, 64,
   (((((uintmax_t) 0xfa3cU << 28 | 0xb3cd496U)
      << 28 | 0x174ec26U)
     << 28 | 0x6b51521U)
    << 28 | 0x6cb9f2fU),
   UINTMAX_MAX / 1999)
P (4, 66,
   (((((uintmax_t) 0x5c05U << 28 | 0x9fa1eedU)
      << 28 | 0xfaa1ce2U)
     << 28 | 0x79edd9eU)
    << 28 | 0x9c2e85bU),
   UINTMAX_MAX / 2003)
P (8, 70,
   (((((uintmax_t) 0x8e52U << 28 | 0x3c5712bU)
      << 28 | 0x68c48d0U)
     << 28 | 0xc591c22U)
    << 28 | 0x1dc9c53U),
   UINTMAX_MAX / 2011)
P (6, 66,
   (((((uintmax_t) 0x8de5U << 28 | 0xdaaf67bU)
      << 28 | 0x1d10a06U)
     << 28 | 0xda8ee9cU)
    << 28 | 0x9ee7c21U),
   UINTMAX_MAX / 2017)
P (10, 60,
   (((((uintmax_t) 0xec2bU << 28 | 0xf35ed8fU)
      << 28 | 0x98f179dU)
     << 28 | 0xfebcaf4U)
    << 28 | 0xc27e8c3U),
   UINTMAX_MAX / 2027)
P (2, 60,
   (((((uintmax_t) 0xe8c8U << 28 | 0xdd0cfedU)
      << 28 | 0xd4d9849U)
     << 28 | 0xaeff9f1U)
    << 28 | 0x9dd6de5U),
   UINTMAX_MAX / 2029)
P (10, 60,
   (((((uintmax_t) 0x65f2U << 28 | 0xb107280U)
      << 28 | 0xd0eb086U)
     << 28 | 0x976a57aU)
    << 28 | 0x296e9c7U),
   UINTMAX_MAX / 2039)
P (14, 58,
   (((((uintmax_t) 0x44b5U << 28 | 0x0ed6b9cU)
      << 28 | 0xbe093a3U)
     << 28 | 0xb9abf48U)
    << 28 | 0x72b84cdU),
   UINTMAX_MAX / 2053)
P (10, 50,
   (((((uintmax_t) 0x9e96U << 28 | 0xa5899dfU)
      << 28 | 0x7cf5b34U)
     << 28 | 0xfca6483U)
    << 28 | 0x895e6efU),
   UINTMAX_MAX / 2063)
P (6, 60,
   (((((uintmax_t) 0x49beU << 28 | 0x6c24212U)
      << 28 | 0x8f47e34U)
     << 28 | 0xb5a3339U)
    << 28 | 0x88f873dU),
   UINTMAX_MAX / 2069)
P (12, 50,
   (((((uintmax_t) 0xd1fdU << 28 | 0xc922526U)
      << 28 | 0xc0275d9U)
     << 28 | 0xdd4f19bU)
    << 28 | 0x5f17be1U),
   UINTMAX_MAX / 2081)
P (2, 54,
   (((((uintmax_t) 0xb8d7U << 28 | 0x51f95d0U)
      << 28 | 0x8f8bfb9U)
     << 28 | 0x35b507fU)
    << 28 | 0xd0ce78bU),
   UINTMAX_MAX / 2083)
P (4, 54,
   (((((uintmax_t) 0x971fU << 28 | 0x47835f8U)
      << 28 | 0xe2aeeb4U)
     << 28 | 0x50f5540U)
    << 28 | 0x660e797U),
   UINTMAX_MAX / 2087)
P (2, 54,
   (((((uintmax_t) 0x418fU << 28 | 0xfe0a0c7U)
      << 28 | 0xff05063U)
     << 28 | 0xff82831U)
    << 28 | 0xffc1419U),
   UINTMAX_MAX / 2089)
P (10, 54,
   (((((uintmax_t) 0xd06fU << 28 | 0x3ae8760U)
      << 28 | 0xf5e0889U)
     << 28 | 0x92f718cU)
    << 28 | 0x22a32fbU),
   UINTMAX_MAX / 2099)
P (12, 50,
   (((((uintmax_t) 0x16adU << 28 | 0x6a5a779U)
      << 28 | 0x25f515fU)
     << 28 | 0x3253ad0U)
    << 28 | 0xd37e7bfU),
   UINTMAX_MAX / 2111)
P (2, 66,
   (((((uintmax_t) 0xfe0fU << 28 | 0xc007c0fU)
      << 28 | 0xfe0fc00U)
     << 28 | 0x7c0ffe0U)
    << 28 | 0xfc007c1U),
   UINTMAX_MAX / 2113)
P (16, 74,
   (((((uintmax_t) 0x9763U << 28 | 0x3395b43U)
      << 28 | 0xf020b4dU)
     << 28 | 0x8ebadc0U)
    << 28 | 0xc0640b1U),
   UINTMAX_MAX / 2129)
P (2, 76,
   (((((uintmax_t) 0x9a20U << 28 | 0xea7f195U)
      << 28 | 0x90471e2U)
     << 28 | 0x729af83U)
    << 28 | 0x1037bdbU),
   UINTMAX_MAX / 2131)
P (6, 76,
   (((((uintmax_t) 0x7285U << 28 | 0xee07e80U)
      << 28 | 0xa8ab8b8U)
     << 28 | 0xf64bf30U)
    << 28 | 0xfeebfe9U),
   UINTMAX_MAX / 2137)
P (4, 80,
   (((((uintmax_t) 0x3dd1U << 28 | 0x5e1a10fU)
      << 28 | 0xa9e8cdaU)
     << 28 | 0x93124b5U)
    << 28 | 0x44c0bf5U),
   UINTMAX_MAX / 2141)
P (2, 94,
   (((((uintmax_t) 0x4f14U << 28 | 0xe7bff85U)
      << 28 | 0xac9e29cU)
     << 28 | 0xf7ff0b5U)
    << 28 | 0x93c539fU),
   UINTMAX_MAX / 2143)
P (10, 86,
   (((((uintmax_t) 0x12e7U << 28 | 0xdccdf10U)
      << 28 | 0x4a322d6U)
     << 28 | 0xbd8861fU)
    << 28 | 0xa0e07d9U),
   UINTMAX_MAX / 2153)
P (8, 82,
   (((((uintmax_t) 0xd7b8U << 28 | 0xebfac9aU)
      << 28 | 0x00b5f5cU)
     << 28 | 0xfe75c0bU)
    << 28 | 0xd8ab891U),
   UINTMAX_MAX / 2161)
P (18, 72,
   (((((uintmax_t) 0xae1cU << 28 | 0xe6bd9efU)
      << 28 | 0x512ea43U)
     << 28 | 0xe808757U)
    << 28 | 0xc2e862bU),
   UINTMAX_MAX / 2179)
P (24, 64,
   (((((uintmax_t) 0x459bU << 28 | 0x5dc70f3U)
      << 28 | 0x90e8690U)
     << 28 | 0xcaa96d5U)
    << 28 | 0x95c9d93U),
   UINTMAX_MAX / 2203)
P (4, 62,
   (((((uintmax_t) 0x4ec2U << 28 | 0xa38d65bU)
      << 28 | 0xa2bd88fU)
     << 28 | 0xd550625U)
    << 28 | 0xd07135fU),
   UINTMAX_MAX / 2207)
P (6, 60,
   (((((uintmax_t) 0x525dU << 28 | 0x3cf6a14U)
      << 28 | 0x20da676U)
     << 28 | 0xb010a86U)
    << 28 | 0xe209f2dU),
   UINTMAX_MAX / 2213)
P (8, 60,
   (((((uintmax_t) 0x716bU << 28 | 0x4f6a9e5U)
      << 28 | 0xf3522ecU)
     << 28 | 0xc042644U)
    << 28 | 0x7769b25U),
   UINTMAX_MAX / 2221)
P (16, 50,
   (((((uintmax_t) 0x48abU << 28 | 0x336212fU)
      << 28 | 0xf32ece3U)
     << 28 | 0x81339caU)
    << 28 | 0xabe3295U),
   UINTMAX_MAX / 2237)
P (2, 54,
   (((((uintmax_t) 0xbde9U << 28 | 0xd1944b7U)
      << 28 | 0x656aad1U)
     << 28 | 0xb190a2dU)
    << 28 | 0x0c7673fU),
   UINTMAX_MAX / 2239)
P (4, 54,
   (((((uintmax_t) 0xb595U << 28 | 0xdb3fccdU)
      << 28 | 0xe54afc3U)
     << 28 | 0xbce3cf2U)
    << 28 | 0x6b0e7ebU),
   UINTMAX_MAX / 2243)
P (8, 58,
   (((((uintmax_t) 0x8a10U << 28 | 0x9aab45fU)
      << 28 | 0x137285fU)
     << 28 | 0x87e76f5U)
    << 28 | 0x6c61ce3U),
   UINTMAX_MAX / 2251)
P (16, 44,
   (((((uintmax_t) 0x2e69U << 28 | 0x78b763bU)
      << 28 | 0x65f88c0U)
     << 28 | 0x6c6857aU)
    << 28 | 0x124b353U),
   UINTMAX_MAX / 2267)
P (2, 64,
   (((((uintmax_t) 0x7e40U << 28 | 0x4f6dc75U)
      << 28 | 0xca11d38U)
     << 28 | 0xc040fcbU)
    << 28 | 0xa630f75U),
   UINTMAX_MAX / 2269)
P (4, 66,
   (((((uintmax_t) 0xa706U << 28 | 0x6b72173U)
      << 28 | 0x37865d0U)
     << 28 | 0x78bc4fbU)
    << 28 | 0xd533b21U),
   UINTMAX_MAX / 2273)
P (8, 60,
   (((((uintmax_t) 0x1165U << 28 | 0x5853800U)
      << 28 | 0xe5d99deU)
     << 28 | 0x8e15c5dU)
    << 28 | 0xd354f59U),
   UINTMAX_MAX / 2281)
P (6, 60,
   (((((uintmax_t) 0xad0dU << 28 | 0xfdfc31bU)
      << 28 | 0x33610caU)
     << 28 | 0x61d53d7U)
    << 28 | 0x414260fU),
   UINTMAX_MAX / 2287)
P (6, 58,
   (((((uintmax_t) 0x65b5U << 28 | 0x32cc4f0U)
      << 28 | 0xb46abb5U)
     << 28 | 0x6bf5ba8U)
    << 28 | 0xeae635dU),
   UINTMAX_MAX / 2293)
P (4, 60,
   (((((uintmax_t) 0xcdbcU << 28 | 0x7622fecU)
      << 28 | 0x6285844U)
     << 28 | 0xa72cb0fU)
    << 28 | 0xb6e3949U),
   UINTMAX_MAX / 2297)
P (12, 62,
   (((((uintmax_t) 0x37c4U << 28 | 0x92cae49U)
      << 28 | 0xd6fa587U)
     << 28 | 0x9839a71U)
    << 28 | 0x4f45bcdU),
   UINTMAX_MAX / 2309)
P (2, 66,
   (((((uintmax_t) 0xc031U << 28 | 0xa083283U)
      << 28 | 0x60ed802U)
     << 28 | 0xa8994fdU)
    << 28 | 0xe5314b7U),
   UINTMAX_MAX / 2311)
P (22, 48,
   (((((uintmax_t) 0xc841U << 28 | 0xd685a6aU)
      << 28 | 0xe081eb9U)
     << 28 | 0x71920cfU)
    << 28 | 0x2b90135U),
   UINTMAX_MAX / 2333)
P (6, 44,
   (((((uintmax_t) 0xc4c9U << 28 | 0xd2b0364U)
      << 28 | 0x9549a8aU)
     << 28 | 0x8fd0b7dU)
    << 28 | 0xf9a6e8bU),
   UINTMAX_MAX / 2339)
P (2, 48,
   (((((uintmax_t) 0xe3c9U << 28 | 0x5290213U)
      << 28 | 0xe7112b3U)
     << 28 | 0x1f9a84cU)
    << 28 | 0x1c6eaadU),
   UINTMAX_MAX / 2341)
P (6, 46,
   (((((uintmax_t) 0xf02fU << 28 | 0x1ede4bbU)
      << 28 | 0x2c64c92U)
     << 28 | 0x293b028U)
    << 28 | 0x23c6d83U),
   UINTMAX_MAX / 2347)
P (4, 48,
   (((((uintmax_t) 0x83f9U << 28 | 0x7773bffU)
      << 28 | 0x907f2eeU)
     << 28 | 0xe77ff20U)
    << 28 | 0xfe5ddcfU),
   UINTMAX_MAX / 2351)
P (6, 54,
   (((((uintmax_t) 0xd472U << 28 | 0x42b02b7U)
      << 28 | 0x1ef460eU)
     << 28 | 0x1ea0f6cU)
    << 28 | 0x496c11dU),
   UINTMAX_MAX / 2357)
P (14, 46,
   (((((uintmax_t) 0xd905U << 28 | 0xb8f4727U)
      << 28 | 0x318f0fdU)
     << 28 | 0xf2d3d6fU)
    << 28 | 0x88ccb6bU),
   UINTMAX_MAX / 2371)
P (6, 46,
   (((((uintmax_t) 0xf2c0U << 28 | 0xc7e3914U)
      << 28 | 0x920a1faU)
     << 28 | 0x9d74a34U)
    << 28 | 0x57738f9U),
   UINTMAX_MAX / 2377)
P (4, 56,
   (((((uintmax_t) 0x6c7cU << 28 | 0x4a67008U)
      << 28 | 0x99f72efU)
     << 28 | 0xc3ca3dbU)
    << 28 | 0x71a5785U),
   UINTMAX_MAX / 2381)
P (2, 58,
   (((((uintmax_t) 0x7e55U << 28 | 0xba2c0b9U)
      << 28 | 0xa289b8eU)
     << 28 | 0x2071718U)
    << 28 | 0xd0d6dafU),
   UINTMAX_MAX / 2383)
P (6, 58,
   (((((uintmax_t) 0xbf46U << 28 | 0xd4d0be4U)
      << 28 | 0xff091bcU)
     << 28 | 0x0fdbfebU)
    << 28 | 0x6cfabfdU),
   UINTMAX_MAX / 2389)
P (4, 66,
   (((((uintmax_t) 0x1908U << 28 | 0x738977bU)
      << 28 | 0x58af71eU)
     << 28 | 0xeab613eU)
    << 28 | 0x5e5aee9U),
   UINTMAX_MAX / 2393)
P (6, 68,
   (((((uintmax_t) 0x6a48U << 28 | 0xc6e8d7fU)
      << 28 | 0xbbb472dU)
     << 28 | 0x2388e90U)
    << 28 | 0xe9e929fU),
   UINTMAX_MAX / 2399)
P (12, 62,
   (((((uintmax_t) 0x9f7bU << 28 | 0x7cc2f24U)
      << 28 | 0xd82eb81U)
     << 28 | 0xdbafba5U)
    << 28 | 0x88ddb43U),
   UINTMAX_MAX / 2411)
P (6, 60,
   (((((uintmax_t) 0x57ceU << 28 | 0x01e8101U)
      << 28 | 0x96b8152U)
     << 28 | 0xeebc51cU)
    << 28 | 0x4799791U),
   UINTMAX_MAX / 2417)
P (6, 80,
   (((((uintmax_t) 0x22c2U << 28 | 0x9d6cb7dU)
      << 28 | 0x695651cU)
     << 28 | 0x6bc4693U)
    << 28 | 0xb45a047U),
   UINTMAX_MAX / 2423)
P (14, 84,
   (((((uintmax_t) 0x366aU << 28 | 0x190050aU)
      << 28 | 0xd1e2606U)
     << 28 | 0xeee0974U)
    << 28 | 0x498874dU),
   UINTMAX_MAX / 2437)
P (4, 90,
   (((((uintmax_t) 0x7708U << 28 | 0x7eb0665U)
      << 28 | 0xba929d8U)
     << 28 | 0x5b7377aU)
    << 28 | 0x9953cb9U),
   UINTMAX_MAX / 2441)
P (6, 92,
   (((((uintmax_t) 0x8f53U << 28 | 0x96f6b06U)
      << 28 | 0x2c2614bU)
     << 28 | 0x6df412dU)
    << 28 | 0x4caf56fU),
   UINTMAX_MAX / 2447)
P (12, 84,
   (((((uintmax_t) 0x0c2eU << 28 | 0x394250fU)
      << 28 | 0xedad56bU)
     << 28 | 0x8afbbb4U)
    << 28 | 0xa053493U),
   UINTMAX_MAX / 2459)
P (8, 82,
   (((((uintmax_t) 0x78afU << 28 | 0x29d1b7fU)
      << 28 | 0xbd965ccU)
     << 28 | 0x5299c96U)
    << 28 | 0xac7720bU),
   UINTMAX_MAX / 2467)
P (6, 78,
   (((((uintmax_t) 0x1287U << 28 | 0x9bcb69bU)
      << 28 | 0x11e89adU)
     << 28 | 0xce84b5cU)
    << 28 | 0x710aa99U),
   UINTMAX_MAX / 2473)
P (4, 80,
   (((((uintmax_t) 0x92c2U << 28 | 0x17c54bfU)
      << 28 | 0x67de19dU)
     << 28 | 0x673f5aaU)
    << 28 | 0x3804225U),
   UINTMAX_MAX / 2477)
P (26, 76,
   (((((uintmax_t) 0xd46eU << 28 | 0x0ce30e3U)
      << 28 | 0x76f2ce6U)
     << 28 | 0x541268eU)
    << 28 | 0xfbce7f7U),
   UINTMAX_MAX / 2503)
P (18, 70,
   (((((uintmax_t) 0xa49bU << 28 | 0x91ec4ccU)
      << 28 | 0x5004dfcU)
     << 28 | 0xf41e76cU)
    << 28 | 0xf5be669U),
   UINTMAX_MAX / 2521)
P (10, 62,
   (((((uintmax_t) 0x6098U << 28 | 0x1f8eb77U)
      << 28 | 0xa7cd05cU)
     << 28 | 0x3eb5dc3U)
    << 28 | 0x1c383cbU),
   UINTMAX_MAX / 2531)
P (8, 70,
   (((((uintmax_t) 0x62e9U << 28 | 0x505bf44U)
      << 28 | 0xdd6a930U)
     << 28 | 0x1832d11U)
    << 28 | 0xd8ad6c3U),
   UINTMAX_MAX / 2539)
P (4, 74,
   (((((uintmax_t) 0xb3cbU << 28 | 0x3fecabfU)
      << 28 | 0x119df2eU)
     << 28 | 0x9c0942fU)
    << 28 | 0x1ce450fU),
   UINTMAX_MAX / 2543)
P (6, 72,
   (((((uintmax_t) 0xef3aU << 28 | 0x59c92a1U)
      << 28 | 0x4b05b97U)
     << 28 | 0xf3f2be3U)
    << 28 | 0x7a39a5dU),
   UINTMAX_MAX / 2549)
P (2, 82,
   (((((uintmax_t) 0xe69cU << 28 | 0x5983c36U)
      << 28 | 0x30c57e8U)
     << 28 | 0xb7d8a96U)
    << 28 | 0x54187c7U),
   UINTMAX_MAX / 2551)
P (6, 90,
   (((((uintmax_t) 0x437aU << 28 | 0xa4cb09bU)
      << 28 | 0x61d08b5U)
     << 28 | 0xd024d7dU)
    << 28 | 0xa5b1b55U),
   UINTMAX_MAX / 2557)
P (22, 78,
   (((((uintmax_t) 0x1b65U << 28 | 0x8bdca98U)
      << 28 | 0xaabb9b8U)
     << 28 | 0xba9d6e7U)
    << 28 | 0xae3501bU),
   UINTMAX_MAX / 2579)
P (12, 68,
   (((((uintmax_t) 0x3ea4U << 28 | 0x3624f3dU)
      << 28 | 0x8dfb0f5U)
     << 28 | 0x0865f71U)
    << 28 | 0xb90f1dfU),
   UINTMAX_MAX / 2591)
P (2, 70,
   (((((uintmax_t) 0x2d05U << 28 | 0x08fbf3cU)
      << 28 | 0x1ffcd73U)
     << 28 | 0x9c16828U)
    << 28 | 0x47df9e1U),
   UINTMAX_MAX / 2593)
P (16, 62,
   (((((uintmax_t) 0xc716U << 28 | 0xdcc634cU)
      << 28 | 0xa218ec4U)
     << 28 | 0x70a4d84U)
    << 28 | 0x2b90ed1U),
   UINTMAX_MAX / 2609)
P (8, 60,
   (((((uintmax_t) 0xe30bU << 28 | 0x71f669dU)
      << 28 | 0x7e49c1fU)
     << 28 | 0xb1be116U)
    << 28 | 0x98cc409U),
   UINTMAX_MAX / 2617)
P (4, 62,
   (((((uintmax_t) 0xa624U << 28 | 0x238d871U)
      << 28 | 0x4cde4d8U)
     << 28 | 0xd5512a7U)
    << 28 | 0xcd35d15U),
   UINTMAX_MAX / 2621)
P (12, 54,
   (((((uintmax_t) 0x6488U << 28 | 0x81e55c1U)
      << 28 | 0x30e7ca5U)
     << 28 | 0x4968217U)
    << 28 | 0x23e07f9U),
   UINTMAX_MAX / 2633)
P (14, 42,
   (((((uintmax_t) 0x8513U << 28 | 0xd3830beU)
      << 28 | 0x54ea0bcU)
     << 28 | 0xc8c6d7aU)
    << 28 | 0xbaa8167U),
   UINTMAX_MAX / 2647)
P (10, 36,
   (((((uintmax_t) 0x49b5U << 28 | 0x0a4f32fU)
      << 28 | 0x800c552U)
     << 28 | 0xc396c95U)
    << 28 | 0xeb619a1U),
   UINTMAX_MAX / 2657)
P (2, 40,
   (((((uintmax_t) 0xa1f0U << 28 | 0x049f0c9U)
      << 28 | 0xcbd166eU)
     << 28 | 0xb7e3808U)
    << 28 | 0x78ec74bU),
   UINTMAX_MAX / 2659)
P (4, 44,
   (((((uintmax_t) 0x25f8U << 28 | 0xe2df380U)
      << 28 | 0xb892e3dU)
     << 28 | 0x5513b50U)
    << 28 | 0x4537157U),
   UINTMAX_MAX / 2663)
P (8, 40,
   (((((uintmax_t) 0x1654U << 28 | 0xeb02967U)
      << 28 | 0x9b8e231U)
     << 28 | 0x4391f88U)
    << 28 | 0x62e948fU),
   UINTMAX_MAX / 2671)
P (6, 36,
   (((((uintmax_t) 0x304aU << 28 | 0xf935d6eU)
      << 28 | 0x11c97dcU)
     << 28 | 0x0b17cfcU)
    << 28 | 0xd81f5ddU),
   UINTMAX_MAX / 2677)
P (6, 36,
   (((((uintmax_t) 0xef7eU << 28 | 0x3c1c9feU)
      << 28 | 0xaa07d2fU)
     << 28 | 0x6bea3ecU)
    << 28 | 0x89044b3U),
   UINTMAX_MAX / 2683)
P (4, 42,
   (((((uintmax_t) 0xd02cU << 28 | 0x34f8dabU)
      << 28 | 0xf7ff3ceU)
     << 28 | 0x13a0586U)
    << 28 | 0x9f1b57fU),
   UINTMAX_MAX / 2687)
P (2, 42,
   (((((uintmax_t) 0xca7fU << 28 | 0x00185f3U)
      << 28 | 0x3e2ad75U)
     << 28 | 0x93474e8U)
    << 28 | 0xace3581U),
   UINTMAX_MAX / 2689)
P (4, 48,
   (((((uintmax_t) 0x613fU << 28 | 0x67e6e76U)
      << 28 | 0x10ebc07U)
     << 28 | 0xfc32929U)
    << 28 | 0x5a05e4dU),
   UINTMAX_MAX / 2693)
P (6, 50,
   (((((uintmax_t) 0x91e1U << 28 | 0x1433fa4U)
      << 28 | 0xf1ad7b0U)
     << 28 | 0x5377cbaU)
    << 28 | 0x4908d23U),
   UINTMAX_MAX / 2699)
P (8, 46,
   (((((uintmax_t) 0x99c5U << 28 | 0x2d7ced2U)
      << 28 | 0xe3e9ae7U)
     << 28 | 0xb2131a6U)
    << 28 | 0x28aa39bU),
   UINTMAX_MAX / 2707)
P (4, 56,
   (((((uintmax_t) 0xe699U << 28 | 0x2a662c6U)
      << 28 | 0x1d45f90U)
     << 28 | 0x31dbed7U)
    << 28 | 0xde01527U),
   UINTMAX_MAX / 2711)
P (2, 64,
   (((((uintmax_t) 0x86efU << 28 | 0x7ca673aU)
      << 28 | 0xf9ad876U)
     << 28 | 0x844b1c6U)
    << 28 | 0x70aa9a9U),
   UINTMAX_MAX / 2713)
P (6, 70,
   (((((uintmax_t) 0xb29bU << 28 | 0x59ea585U)
      << 28 | 0x098266aU)
     << 28 | 0x03f4533U)
    << 28 | 0xb08915fU),
   UINTMAX_MAX / 2719)
P (10, 62,
   (((((uintmax_t) 0x2d67U << 28 | 0x181bc45U)
      << 28 | 0x6ad8b1dU)
     << 28 | 0xbca579dU)
    << 28 | 0xb0a3999U),
   UINTMAX_MAX / 2729)
P (2, 66,
   (((((uintmax_t) 0xffa0U << 28 | 0x02ffe80U)
      << 28 | 0x0bffa00U)
     << 28 | 0x2ffe800U)
    << 28 | 0xbffa003U),
   UINTMAX_MAX / 2731)
P (10, 60,
   (((((uintmax_t) 0xef00U << 28 | 0x778c303U)
      << 28 | 0x1503a47U)
     << 28 | 0x8ab1a3eU)
    << 28 | 0x936139dU),
   UINTMAX_MAX / 2741)
P (8, 54,
   (((((uintmax_t) 0xd453U << 28 | 0x113a63aU)
      << 28 | 0x4bcdb66U)
     << 28 | 0xe722bc4U)
    << 28 | 0xc5cc095U),
   UINTMAX_MAX / 2749)
P (4, 66,
   (((((uintmax_t) 0x01c4U << 28 | 0x4cfeca8U)
      << 28 | 0x7f35a7aU)
     << 28 | 0x8f63c71U)
    << 28 | 0x7278541U),
   UINTMAX_MAX / 2753)
P (14, 66,
   (((((uintmax_t) 0x3887U << 28 | 0x72a189cU)
      << 28 | 0x2c09fdfU)
     << 28 | 0x6eee24dU)
    << 28 | 0x292bc2fU),
   UINTMAX_MAX / 2767)
P (10, 60,
   (((((uintmax_t) 0x835dU << 28 | 0x625cbd2U)
      << 28 | 0xa50339fU)
     << 28 | 0xc20d172U)
    << 28 | 0x37dd569U),
   UINTMAX_MAX / 2777)
P (12, 54,
   (((((uintmax_t) 0x8052U << 28 | 0x3e3ba9bU)
      << 28 | 0x7da8ccdU)
     << 28 | 0xf993235U)
    << 28 | 0x6bda2edU),
   UINTMAX_MAX / 2789)
P (2, 60,
   (((((uintmax_t) 0xced6U << 28 | 0x1518ac7U)
      << 28 | 0x0a2e697U)
     << 28 | 0xb5e332eU)
    << 28 | 0x80f68d7U),
   UINTMAX_MAX / 2791)
P (6, 60,
   (((((uintmax_t) 0x42d0U << 28 | 0x7f67b31U)
      << 28 | 0xe1cbd46U)
     << 28 | 0xeee26fdU)
    << 28 | 0x875e2e5U),
   UINTMAX_MAX / 2797)
P (4, 60,
   (((((uintmax_t) 0xa787U << 28 | 0x5b7cc16U)
      << 28 | 0x4cf4935U)
     << 28 | 0x48a8e65U)
    << 28 | 0x157a611U),
   UINTMAX_MAX / 2801)
P (2, 76,
   (((((uintmax_t) 0x69abU << 28 | 0x6d816a6U)
      << 28 | 0x6791ac2U)
     << 28 | 0x88d03beU)
    << 28 | 0x9b71e3bU),
   UINTMAX_MAX / 2803)
P (16, 68,
   (((((uintmax_t) 0xace8U << 28 | 0x1dc954bU)
      << 28 | 0xa58d081U)
     << 28 | 0x51186dbU)
    << 28 | 0x38937abU),
   UINTMAX_MAX / 2819)
P (14, 64,
   (((((uintmax_t) 0x7c3fU << 28 | 0xfa377bbU)
      << 28 | 0x52dd078U)
     << 28 | 0x00b9108U)
    << 28 | 0x95a45f1U),
   UINTMAX_MAX / 2833)
P (4, 66,
   (((((uintmax_t) 0x1f0aU << 28 | 0x8ec0eccU)
      << 28 | 0x79a36aeU)
     << 28 | 0xe0b0241U)
    << 28 | 0x82eec3dU),
   UINTMAX_MAX / 2837)
P (6, 66,
   (((((uintmax_t) 0x609eU << 28 | 0x7b00a15U)
      << 28 | 0xca83496U)
     << 28 | 0x323eda1U)
    << 28 | 0x73b5713U),
   UINTMAX_MAX / 2843)
P (8, 66,
   (((((uintmax_t) 0x7362U << 28 | 0x52ca08cU)
      << 28 | 0xcba690eU)
     << 28 | 0xd0dbd03U)
    << 28 | 0xae77c8bU),
   UINTMAX_MAX / 2851)
P (6, 70,
   (((((uintmax_t) 0xa370U << 28 | 0x463ffa4U)
      << 28 | 0x3eb91f7U)
     << 28 | 0x3800b78U)
    << 28 | 0x28dc119U),
   UINTMAX_MAX / 2857)
P (4, 78,
   (((((uintmax_t) 0x4586U << 28 | 0x7cbbe80U)
      << 28 | 0x502c61bU)
     << 28 | 0x61715ecU)
    << 28 | 0x22b7ca5U),
   UINTMAX_MAX / 2861)
P (18, 74,
   (((((uintmax_t) 0x508fU << 28 | 0xb1c027dU)
      << 28 | 0x607a5a8U)
     << 28 | 0x533a991U)
    << 28 | 0xead64bfU),
   UINTMAX_MAX / 2879)
P (8, 70,
   (((((uintmax_t) 0xbc40U << 28 | 0xe8adccbU)
      << 28 | 0xf2e057fU)
     << 28 | 0x6c7290eU)
    << 28 | 0x46c2e77U),
   UINTMAX_MAX / 2887)
P (10, 66,
   (((((uintmax_t) 0x73d9U << 28 | 0x78cc4e1U)
      << 28 | 0xdde3e63U)
     << 28 | 0x25e8d90U)
    << 28 | 0x7b01db1U),
   UINTMAX_MAX / 2897)
P (6, 66,
   (((((uintmax_t) 0x1c21U << 28 | 0x8299f86U)
      << 28 | 0xa86ec28U)
     << 28 | 0x909f701U)
    << 28 | 0x52a1067U),
   UINTMAX_MAX / 2903)
P (6, 62,
   (((((uintmax_t) 0x5da2U << 28 | 0x8a842e1U)
      << 28 | 0xd0a78eaU)
     << 28 | 0x7077af0U)
    << 28 | 0x997a0f5U),
   UINTMAX_MAX / 2909)
P (8, 82,
   (((((uintmax_t) 0x21f6U << 28 | 0xb281b61U)
      << 28 | 0xadae07eU)
     << 28 | 0x605cad1U)
    << 28 | 0x0c32e6dU),
   UINTMAX_MAX / 2917)
P (10, 74,
   (((((uintmax_t) 0x2e9dU << 28 | 0xf4a1477U)
      << 28 | 0x4c2dd47U)
     << 28 | 0x1b33570U)
    << 28 | 0x635b38fU),
   UINTMAX_MAX / 2927)
P (12, 72,
   (((((uintmax_t) 0x891aU << 28 | 0x37ebcabU)
      << 28 | 0x12ba3abU)
     << 28 | 0x559fa99U)
    << 28 | 0x7a61bb3U),
   UINTMAX_MAX / 2939)
P (14, 66,
   (((((uintmax_t) 0xccadU << 28 | 0xbad1f78U)
      << 28 | 0x11569adU)
     << 28 | 0x4bdae56U)
    << 28 | 0x2bddab9U),
   UINTMAX_MAX / 2953)
P (4, 66,
   (((((uintmax_t) 0xb335U << 28 | 0x6a92a82U)
      << 28 | 0x08d4a05U)
     << 28 | 0x5e1b2f2U)
    << 28 | 0xed62f45U),
   UINTMAX_MAX / 2957)
P (6, 74,
   (((((uintmax_t) 0x58bbU << 28 | 0x5017802U)
      << 28 | 0x12d5c03U)
     << 28 | 0xcd328b1U)
    << 28 | 0xa2dca9bU),
   UINTMAX_MAX / 2963)
P (6, 72,
   (((((uintmax_t) 0x7501U << 28 | 0xa365242U)
      << 28 | 0x0c3e6d2U)
     << 28 | 0x8f4e087U)
    << 28 | 0x33218a9U),
   UINTMAX_MAX / 2969)
P (2, 78,
   (((((uintmax_t) 0x18a4U << 28 | 0xbffa7c4U)
      << 28 | 0x073ceb6U)
     << 28 | 0x800b077U)
    << 28 | 0xf186293U),
   UINTMAX_MAX / 2971)
P (28, 62,
   (((((uintmax_t) 0xa633U << 28 | 0x0bdd838U)
      << 28 | 0xae2356fU)
     << 28 | 0xbd138c3U)
    << 28 | 0xfd9c207U),
   UINTMAX_MAX / 2999)
P (2, 66,
   (((((uintmax_t) 0xe2ffU << 28 | 0x0fc80a3U)
      << 28 | 0xc9104b1U)
     << 28 | 0x17ccd12U)
    << 28 | 0xae88a89U),
   UINTMAX_MAX / 3001)
P (10, 68,
   (((((uintmax_t) 0x1183U << 28 | 0xb2cce6eU)
      << 28 | 0xb2b722fU)
     << 28 | 0x1a1a044U)
    << 28 | 0x046bcebU),
   UINTMAX_MAX / 3011)
P (8, 64,
   (((((uintmax_t) 0xbfb9U << 28 | 0x73118d8U)
      << 28 | 0x666f154U)
     << 28 | 0x8aba0b0U)
    << 28 | 0x60541e3U),
   UINTMAX_MAX / 3019)
P (4, 66,
   (((((uintmax_t) 0xa152U << 28 | 0xbc81bc6U)
      << 28 | 0xc0e90cfU)
     << 28 | 0x4e808ceU)
    << 28 | 0xa111b2fU),
   UINTMAX_MAX / 3023)
P (14, 72,
   (((((uintmax_t) 0xaebdU << 28 | 0xa92d6f2U)
      << 28 | 0xef39bdbU)
     << 28 | 0xec1b4faU)
    << 28 | 0x855a475U),
   UINTMAX_MAX / 3037)
P (4, 78,
   (((((uintmax_t) 0x890cU << 28 | 0xb62bf18U)
      << 28 | 0x542ece3U)
     << 28 | 0xf794eb6U)
    << 28 | 0x00d7821U),
   UINTMAX_MAX / 3041)
P (8, 72,
   (((((uintmax_t) 0x699fU << 28 | 0xc793db6U)
      << 28 | 0x480a134U)
     << 28 | 0xfae0d9aU)
    << 28 | 0x11f7c59U),
   UINTMAX_MAX / 3049)
P (12, 76,
   (((((uintmax_t) 0x14fdU << 28 | 0xe8c0055U)
      << 28 | 0xa3d62f0U)
     << 28 | 0x06b0ccbU)
    << 28 | 0xbac085dU),
   UINTMAX_MAX / 3061)
P (6, 96,
   (((((uintmax_t) 0xa99cU << 28 | 0x01006adU)
      << 28 | 0x72efe3fU)
     << 28 | 0x45076dcU)
    << 28 | 0x3114733U),
   UINTMAX_MAX / 3067)
P (12, 88,
   (((((uintmax_t) 0x59e0U << 28 | 0xe778f96U)
      << 28 | 0xe7f8aeeU)
     << 28 | 0xf49bfa5U)
    << 28 | 0x8a1a1b7U),
   UINTMAX_MAX / 3079)
P (4, 86,
   (((((uintmax_t) 0x6edaU << 28 | 0x627b0f3U)
      << 28 | 0x2121a12U)
     << 28 | 0xc4218beU)
    << 28 | 0xa691fa3U),
   UINTMAX_MAX / 3083)
P (6, 92,
   (((((uintmax_t) 0xf88aU << 28 | 0x9107df8U)
      << 28 | 0x35b3ebcU)
     << 28 | 0x7504e3bU)
    << 28 | 0xd5e64f1U),
   UINTMAX_MAX / 3089)
P (20, 78,
   (((((uintmax_t) 0xcddaU << 28 | 0x9dee60fU)
      << 28 | 0xf969a4eU)
     << 28 | 0xe21c292U)
    << 28 | 0xbb92fadU),
   UINTMAX_MAX / 3109)
P (10, 72,
   (((((uintmax_t) 0x4ff1U << 28 | 0x8de982bU)
      << 28 | 0xfe5bc34U)
     << 28 | 0x338b732U)
    << 28 | 0x7a4bacfU),
   UINTMAX_MAX / 3119)
P (2, 82,
   (((((uintmax_t) 0x8fdfU << 28 | 0x30a40ccU)
      << 28 | 0xbc0053fU)
     << 28 | 0xe5c0833U)
    << 28 | 0xd6fccd1U),
   UINTMAX_MAX / 3121)
P (16, 72,
   (((((uintmax_t) 0x0ca6U << 28 | 0x26ae799U)
      << 28 | 0x8087cb1U)
     << 28 | 0xe707435U)
    << 28 | 0x35203c1U),
   UINTMAX_MAX / 3137)
P (26, 54,
   (((((uintmax_t) 0x3a1cU << 28 | 0xa6ba507U)
      << 28 | 0x340aaefU)
     << 28 | 0xbb5dcdfU)
    << 28 | 0xb4e43d3U),
   UINTMAX_MAX / 3163)
P (4, 54,
   (((((uintmax_t) 0x340eU << 28 | 0x8ccfe76U)
      << 28 | 0xd34c8caU)
     << 28 | 0x68467caU)
    << 28 | 0x5394f9fU),
   UINTMAX_MAX / 3167)
P (2, 60,
   (((((uintmax_t) 0xe94cU << 28 | 0xd3010cdU)
      << 28 | 0x82c978cU)
     << 28 | 0x51c0814U)
    << 28 | 0x08b97a1U),
   UINTMAX_MAX / 3169)
P (12, 70,
   (((((uintmax_t) 0x69d4U << 28 | 0x0f213ccU)
      << 28 | 0x2c1a132U)
     << 28 | 0x75a899dU)
    << 28 | 0xfa5dd65U),
   UINTMAX_MAX / 3181)
P (6, 66,
   (((((uintmax_t) 0xcc45U << 28 | 0x14a4d46U)
      << 28 | 0x1ff849eU)
     << 28 | 0x674cb62U)
    << 28 | 0xe1b78bbU),
   UINTMAX_MAX / 3187)
P (4, 66,
   (((((uintmax_t) 0x6351U << 28 | 0xbffadd9U)
      << 28 | 0x54cc6a3U)
     << 28 | 0x7ff5bb2U)
    << 28 | 0xa998d47U),
   UINTMAX_MAX / 3191)
P (12, 56,
   (((((uintmax_t) 0x77baU << 28 | 0x4e2aae1U)
      << 28 | 0x3a95c79U)
     << 28 | 0x2a999dbU)
    << 28 | 0x131a22bU),
   UINTMAX_MAX / 3203)
P (6, 62,
   (((((uintmax_t) 0x8d1fU << 28 | 0x82e96c6U)
      << 28 | 0xa42da1bU)
     << 28 | 0x48841bcU)
    << 28 | 0x30d29b9U),
   UINTMAX_MAX / 3209)
P (8, 82,
   (((((uintmax_t) 0x0ef5U << 28 | 0xe4c8da5U)
      << 28 | 0xc2683f0U)
     << 28 | 0x6721d20U)
    << 28 | 0x11d3471U),
   UINTMAX_MAX / 3217)
P (4, 80,
   (((((uintmax_t) 0x9ccfU << 28 | 0x98fef77U)
      << 28 | 0xeed5293U)
     << 28 | 0xfd2386dU)
    << 28 | 0xff85ebdU),
   UINTMAX_MAX / 3221)
P (8, 78,
   (((((uintmax_t) 0x9c06U << 28 | 0xa8de9f5U)
      << 28 | 0xb182e4cU)
     << 28 | 0xe72f54cU)
    << 28 | 0x07ed9b5U),
   UINTMAX_MAX / 3229)
P (22, 62,
   (((((uintmax_t) 0xdcf5U << 28 | 0x5e929f8U)
      << 28 | 0x99148d6U)
     << 28 | 0xd0fd3e7U)
    << 28 | 0x1dd827bU),
   UINTMAX_MAX / 3251)
P (2, 66,
   (((((uintmax_t) 0xcebcU << 28 | 0x664e397U)
      << 28 | 0x2d17d85U)
     << 28 | 0x6405fb1U)
    << 28 | 0xeed819dU),
   UINTMAX_MAX / 3253)
P (4, 66,
   (((((uintmax_t) 0x921eU << 28 | 0x0671f84U)
      << 28 | 0xc15b18eU)
     << 28 | 0xa8aceb7U)
    << 28 | 0xc443989U),
   UINTMAX_MAX / 3257)
P (2, 70,
   (((((uintmax_t) 0x4223U << 28 | 0xfa07b2bU)
      << 28 | 0x4830634U)
     << 28 | 0xa13026fU)
    << 28 | 0x62e5873U),
   UINTMAX_MAX / 3259)
P (12, 60,
   (((((uintmax_t) 0x4ceeU << 28 | 0xdc3bcb1U)
      << 28 | 0x806e31eU)
     << 28 | 0xea0208eU)
    << 28 | 0xc0af4f7U),
   UINTMAX_MAX / 3271)
P (28, 44,
   (((((uintmax_t) 0x969eU << 28 | 0xc4a2f55U)
      << 28 | 0xe703563U)
     << 28 | 0x679853cU)
    << 28 | 0xea598cbU),
   UINTMAX_MAX / 3299)
P (2, 46,
   (((((uintmax_t) 0xd886U << 28 | 0xa176bb8U)
      << 28 | 0x577a9c3U)
     << 28 | 0x0b3ebd6U)
    << 28 | 0x1f2d0edU),
   UINTMAX_MAX / 3301)
P (6, 52,
   (((((uintmax_t) 0xaaecU << 28 | 0xb97a633U)
      << 28 | 0xdda117eU)
     << 28 | 0xb9037bcU)
    << 28 | 0x7f43bc3U),
   UINTMAX_MAX / 3307)
P (6, 48,
   (((((uintmax_t) 0x1a59U << 28 | 0x7af0505U)
      << 28 | 0xcb9c2a5U)
     << 28 | 0x83e6f6cU)
    << 28 | 0xe016411U),
   UINTMAX_MAX / 3313)
P (6, 52,
   (((((uintmax_t) 0x76c8U << 28 | 0x6358785U)
      << 28 | 0x34d5cf1U)
     << 28 | 0x938d895U)
    << 28 | 0xf1a74c7U),
   UINTMAX_MAX / 3319)
P (4, 50,
   (((((uintmax_t) 0xb781U << 28 | 0xa8058bfU)
      << 28 | 0xac2e880U)
     << 28 | 0xcf1491cU)
    << 28 | 0x1e81e33U),
   UINTMAX_MAX / 3323)
P (6, 60,
   (((((uintmax_t) 0xc604U << 28 | 0x75cf8d9U)
      << 28 | 0x2a5f33cU)
     << 28 | 0x0f12886U)
    << 28 | 0xba8f301U),
   UINTMAX_MAX / 3329)
P (2, 60,
   (((((uintmax_t) 0x9d2aU << 28 | 0x8009d65U)
      << 28 | 0x861c20eU)
     << 28 | 0x4b786e0U)
    << 28 | 0xdfcc5abU),
   UINTMAX_MAX / 3331)
P (12, 64,
   (((((uintmax_t) 0x4053U << 28 | 0x511894dU)
      << 28 | 0xe137367U)
     << 28 | 0x2684c93U)
    << 28 | 0xf2d41efU),
   UINTMAX_MAX / 3343)
P (4, 66,
   (((((uintmax_t) 0xcbfdU << 28 | 0x3f19edcU)
      << 28 | 0xbd615e0U)
     << 28 | 0x0757badU)
    << 28 | 0xb35c51bU),
   UINTMAX_MAX / 3347)
P (12, 74,
   (((((uintmax_t) 0x303eU << 28 | 0x309fbe2U)
      << 28 | 0x6de63d6U)
     << 28 | 0xd84afe6U)
    << 28 | 0x6472edfU),
   UINTMAX_MAX / 3359)
P (2, 88,
   (((((uintmax_t) 0x1123U << 28 | 0x440491fU)
      << 28 | 0x00137fbU)
     << 28 | 0xbc0eedcU)
    << 28 | 0xbbfb6e1U),
   UINTMAX_MAX / 3361)
P (10, 86,
   (((((uintmax_t) 0x5ae7U << 28 | 0x03df7f3U)
      << 28 | 0x3de4825U)
     << 28 | 0x0f43aa0U)
    << 28 | 0x8a84983U),
   UINTMAX_MAX / 3371)
P (2, 88,
   (((((uintmax_t) 0x11fcU << 28 | 0xcff5122U)
      << 28 | 0x3abe804U)
     << 28 | 0x400e927U)
    << 28 | 0xb1acaa5U),
   UINTMAX_MAX / 3373)
P (16, 74,
   (((((uintmax_t) 0x80cbU << 28 | 0x0c29652U)
      << 28 | 0x5643d56U)
     << 28 | 0x572be34U)
    << 28 | 0xb9d3215U),
   UINTMAX_MAX / 3389)
P (2, 76,
   (((((uintmax_t) 0xc57dU << 28 | 0xffd958dU)
      << 28 | 0xb3c0487U)
     << 28 | 0x964ef77U)
    << 28 | 0x81c62bfU),
   UINTMAX_MAX / 3391)
P (16, 62,
   (((((uintmax_t) 0x9c4aU << 28 | 0x3cdce8eU)
      << 28 | 0xea48e29U)
     << 28 | 0xed84051U)
    << 28 | 0xc06e9afU),
   UINTMAX_MAX / 3407)
P (6, 78,
   (((((uintmax_t) 0x0cf9U << 28 | 0xeca5ea8U)
      << 28 | 0xc4381b0U)
     << 28 | 0x0acd11eU)
    << 28 | 0xd3f87fdU),
   UINTMAX_MAX / 3413)
P (20, 66,
   (((((uintmax_t) 0xfe48U << 28 | 0xee074edU)
      << 28 | 0x223a506U)
     << 28 | 0x3078817U)
    << 28 | 0x44152d9U),
   UINTMAX_MAX / 3433)
P (16, 62,
   (((((uintmax_t) 0xa409U << 28 | 0x342e04eU)
      << 28 | 0x6187e7aU)
     << 28 | 0x786459fU)
    << 28 | 0x5c1ccc9U),
   UINTMAX_MAX / 3449)
P (8, 60,
   (((((uintmax_t) 0xe4e5U << 28 | 0x902e357U)
      << 28 | 0x74c7f13U)
     << 28 | 0x08125d7U)
    << 28 | 0x4563281U),
   UINTMAX_MAX / 3457)
P (4, 66,
   (((((uintmax_t) 0x7588U << 28 | 0x9dfe5f6U)
      << 28 | 0xae1e539U)
     << 28 | 0x5310a48U)
    << 28 | 0x0b3e34dU),
   UINTMAX_MAX / 3461)
P (2, 66,
   (((((uintmax_t) 0x3784U << 28 | 0x6603fdeU)
      << 28 | 0xe1c3d35U)
     << 28 | 0x985baa8U)
    << 28 | 0xb202837U),
   UINTMAX_MAX / 3463)
P (4, 66,
   (((((uintmax_t) 0xb450U << 28 | 0xa1daeecU)
      << 28 | 0xba5ea96U)
     << 28 | 0x304a6e0U)
    << 28 | 0x52b3223U),
   UINTMAX_MAX / 3467)
P (2, 70,
   (((((uintmax_t) 0xfbf0U << 28 | 0xf20d6e5U)
      << 28 | 0x363d8bdU)
     << 28 | 0x8265fc9U)
    << 28 | 0xaf8fd45U),
   UINTMAX_MAX / 3469)
P (22, 50,
   (((((uintmax_t) 0xeeb1U << 28 | 0x9bd44b6U)
      << 28 | 0x27bee1bU)
     << 28 | 0x6d0b383U)
    << 28 | 0xec58e0bU),
   UINTMAX_MAX / 3491)
P (8, 48,
   (((((uintmax_t) 0x7386U << 28 | 0x8c53fdfU)
      << 28 | 0x38fe9c2U)
     << 28 | 0x1a7c3b6U)
    << 28 | 0x8b28503U),
   UINTMAX_MAX / 3499)
P (12, 46,
   (((((uintmax_t) 0xba13U << 28 | 0x65219cfU)
      << 28 | 0xbb2b623U)
     << 28 | 0x6fa180fU)
    << 28 | 0xbfd6007U),
   UINTMAX_MAX / 3511)
P (6, 42,
   (((((uintmax_t) 0xe16dU << 28 | 0xb1887adU)
      << 28 | 0xe4c6dc4U)
     << 28 | 0x2accd44U)
    << 28 | 0x0ed9595U),
   UINTMAX_MAX / 3517)
P (10, 44,
   (((((uintmax_t) 0x4cf0U << 28 | 0x1ab5e49U)
      << 28 | 0x04b7c7aU)
     << 28 | 0xcf71282U)
    << 28 | 0x36ba3f7U),
   UINTMAX_MAX / 3527)
P (2, 52,
   (((((uintmax_t) 0x6374U << 28 | 0x6df92e5U)
      << 28 | 0xaad5ff9U)
     << 28 | 0x09367a9U)
    << 28 | 0x87b9c79U),
   UINTMAX_MAX / 3529)
P (4, 50,
   (((((uintmax_t) 0x3fc3U << 28 | 0xb6abbabU)
      << 28 | 0xa82dcb6U)
     << 28 | 0x4efb252U)
    << 28 | 0xbfba705U),
   UINTMAX_MAX / 3533)
P (6, 54,
   (((((uintmax_t) 0x82b6U << 28 | 0x6ef6f53U)
      << 28 | 0x8c8ce98U)
     << 28 | 0x0d4f5a7U)
    << 28 | 0xe4cd25bU),
   UINTMAX_MAX / 3539)
P (2, 66,
   (((((uintmax_t) 0x20c0U << 28 | 0x04a07f3U)
      << 28 | 0xdab1fe1U)
     << 28 | 0xecc4ef2U)
    << 28 | 0x7b0c37dU),
   UINTMAX_MAX / 3541)
P (6, 66,
   (((((uintmax_t) 0xfb2aU << 28 | 0x13c68cbU)
      << 28 | 0xd185291U)
     << 28 | 0x11aebb8U)
    << 28 | 0x1d72653U),
   UINTMAX_MAX / 3547)
P (10, 60,
   (((((uintmax_t) 0x8908U << 28 | 0x46d1b90U)
      << 28 | 0x96d9c89U)
     << 28 | 0x51f985cU)
    << 28 | 0xb2c67edU),
   UINTMAX_MAX / 3557)
P (2, 64,
   (((((uintmax_t) 0xf7baU << 28 | 0x5f17856U)
      << 28 | 0xe44e8c4U)
     << 28 | 0x39d4fc5U)
    << 28 | 0x4e0b5d7U),
   UINTMAX_MAX / 3559)
P (12, 60,
   (((((uintmax_t) 0x811cU << 28 | 0x75db26eU)
      << 28 | 0xd4a0de8U)
     << 28 | 0x57bf318U)
    << 28 | 0x96d533bU),
   UINTMAX_MAX / 3571)
P (10, 56,
   (((((uintmax_t) 0x6fbcU << 28 | 0x83d31afU)
      << 28 | 0x37d51b6U)
     << 28 | 0x14bb4cbU)
    << 28 | 0x5023755U),
   UINTMAX_MAX / 3581)
P (2, 60,
   (((((uintmax_t) 0xdf7dU << 28 | 0xad8c657U)
      << 28 | 0x4f61193U)
     << 28 | 0x8a89e54U)
    << 28 | 0x73bf1ffU),
   UINTMAX_MAX / 3583)
P (10, 66,
   (((((uintmax_t) 0x48beU << 28 | 0xf2f618aU)
      << 28 | 0x70259eaU)
     << 28 | 0xc481acaU)
    << 28 | 0x34de039U),
   UINTMAX_MAX / 3593)
P (14, 64,
   (((((uintmax_t) 0x5c8cU << 28 | 0x86d951dU)
      << 28 | 0x4fd8414U)
     << 28 | 0xb961badU)
    << 28 | 0xf4809a7U),
   UINTMAX_MAX / 3607)
P (6, 60,
   (((((uintmax_t) 0x3e35U << 28 | 0xfddfd4eU)
      << 28 | 0xb85d876U)
     << 28 | 0x784fecbU)
    << 28 | 0xa352435U),
   UINTMAX_MAX / 3613)
P (4, 60,
   (((((uintmax_t) 0x3f46U << 28 | 0x480d05dU)
      << 28 | 0xfde06efU)
     << 28 | 0xa689bb5U)
    << 28 | 0x8aef5e1U),
   UINTMAX_MAX / 3617)
P (6, 68,
   (((((uintmax_t) 0xa7f5U << 28 | 0x427da20U)
      << 28 | 0x5cb49b2U)
     << 28 | 0xb2c4db9U)
    << 28 | 0xc3a8197U),
   UINTMAX_MAX / 3623)
P (8, 66,
   (((((uintmax_t) 0x1756U << 28 | 0x39f44bdU)
      << 28 | 0xcbf7d25U)
     << 28 | 0x03bc992U)
    << 28 | 0x279f8cfU),
   UINTMAX_MAX / 3631)
P (6, 64,
   (((((uintmax_t) 0xf7b1U << 28 | 0xba9905dU)
      << 28 | 0x798f3d2U)
     << 28 | 0xab9aec5U)
    << 28 | 0xca1541dU),
   UINTMAX_MAX / 3637)
P (6, 66,
   (((((uintmax_t) 0x0ec1U << 28 | 0xcf3b3d3U)
      << 28 | 0x4ea253eU)
     << 28 | 0x78ba146U)
    << 28 | 0x0f99af3U),
   UINTMAX_MAX / 3643)
P (16, 60,
   (((((uintmax_t) 0x694bU << 28 | 0xe954ddeU)
      << 28 | 0xd63b30aU)
     << 28 | 0x0142657U)
    << 28 | 0x2cfcb63U),
   UINTMAX_MAX / 3659)
P (12, 56,
   (((((uintmax_t) 0xd628U << 28 | 0x9612455U)
      << 28 | 0x13dfebeU)
     << 28 | 0xa857968U)
    << 28 | 0xf3cbd67U),
   UINTMAX_MAX / 3671)
P (2, 60,
   (((((uintmax_t) 0x63bcU << 28 | 0xcfb30dbU)
      << 28 | 0xaffca78U)
     << 28 | 0xdb213eeU)
    << 28 | 0xfe659e9U),
   UINTMAX_MAX / 3673)
P (4, 62,
   (((((uintmax_t) 0x7cf8U << 28 | 0xb08fb32U)
      << 28 | 0x328ba96U)
     << 28 | 0x3e8541aU)
    << 28 | 0x74d35f5U),
   UINTMAX_MAX / 3677)
P (14, 70,
   (((((uintmax_t) 0x99e7U << 28 | 0xb98849cU)
      << 28 | 0xbfb489eU)
     << 28 | 0x22d1527U)
    << 28 | 0x76f2e43U),
   UINTMAX_MAX / 3691)
P (6, 70,
   (((((uintmax_t) 0x1767U << 28 | 0xa90721dU)
      << 28 | 0xc686c05U)
     << 28 | 0xd10d39dU)
    << 28 | 0x1e1f291U),
   UINTMAX_MAX / 3697)
P (4, 68,
   (((((uintmax_t) 0x817cU << 28 | 0xb6e3047U)
      << 28 | 0xeff3d37U)
     << 28 | 0x4468dccU)
    << 28 | 0xaced1ddU),
   UINTMAX_MAX / 3701)
P (8, 70,
   (((((uintmax_t) 0x916dU << 28 | 0x896be15U)
      << 28 | 0xac3548dU)
     << 28 | 0x145c7d1U)
    << 28 | 0x10c5ad5U),
   UINTMAX_MAX / 3709)
P (10, 74,
   (((((uintmax_t) 0x50e1U << 28 | 0xc7f7bd5U)
      << 28 | 0xdf5f332U)
     << 28 | 0x51a39f5U)
    << 28 | 0xacb5737U),
   UINTMAX_MAX / 3719)
P (8, 70,
   (((((uintmax_t) 0xc1e7U << 28 | 0xf58f36eU)
      << 28 | 0x1b567a6U)
     << 28 | 0x6e50171U)
    << 28 | 0x443506fU),
   UINTMAX_MAX / 3727)
P (6, 70,
   (((((uintmax_t) 0xe72cU << 28 | 0xc7f8de3U)
      << 28 | 0x0f6e112U)
     << 28 | 0x4f69ad9U)
    << 28 | 0x1dd4cbdU),
   UINTMAX_MAX / 3733)
P (6, 82,
   (((((uintmax_t) 0x81e2U << 28 | 0x02e029aU)
      << 28 | 0x0d485ecU)
     << 28 | 0x24f8f2aU)
    << 28 | 0x61a2793U),
   UINTMAX_MAX / 3739)
P (22, 62,
   (((((uintmax_t) 0x66a5U << 28 | 0x216bc00U)
      << 28 | 0x45b35b4U)
     << 28 | 0x72148e6U)
    << 28 | 0x56b7a51U),
   UINTMAX_MAX / 3761)
P (6, 66,
   (((((uintmax_t) 0x3442U << 28 | 0x9973536U)
      << 28 | 0x29ba00aU)
     << 28 | 0xdf9570eU)
    << 28 | 0x1142f07U),
   UINTMAX_MAX / 3767)
P (2, 78,
   (((((uintmax_t) 0xc952U << 28 | 0x869f58aU)
      << 28 | 0x38eb489U)
     << 28 | 0xbf33b06U)
    << 28 | 0x5119789U),
   UINTMAX_MAX / 3769)
P (10, 72,
   (((((uintmax_t) 0xc462U << 28 | 0xe78b7b7U)
      << 28 | 0xebf2b8fU)
     << 28 | 0x0149803U)
    << 28 | 0xcb291ebU),
   UINTMAX_MAX / 3779)
P (14, 60,
   (((((uintmax_t) 0xa7b8U << 28 | 0x300e09dU)
      << 28 | 0xa9be883U)
     << 28 | 0x34b63afU)
    << 28 | 0xd190a31U),
   UINTMAX_MAX / 3793)
P (4, 66,
   (((((uintmax_t) 0x678fU << 28 | 0x45607afU)
      << 28 | 0xa226292U)
     << 28 | 0x0908d50U)
    << 28 | 0xd6aba7dU),
   UINTMAX_MAX / 3797)
P (6, 74,
   (((((uintmax_t) 0x3066U << 28 | 0x51b882dU)
      << 28 | 0xc63e557U)
     << 28 | 0xd8b018cU)
    << 28 | 0x5a33d53U),
   UINTMAX_MAX / 3803)
P (18, 60,
   (((((uintmax_t) 0x03f3U << 28 | 0xf0b9737U)
      << 28 | 0x01682eaU)
     << 28 | 0x1773092U)
    << 28 | 0xdc27ee5U),
   UINTMAX_MAX / 3821)
P (2, 66,
   (((((uintmax_t) 0x824fU << 28 | 0x6b12f35U)
      << 28 | 0x80e76caU)
     << 28 | 0xe5f38b7U)
    << 28 | 0xbf2e00fU),
   UINTMAX_MAX / 3823)
P (10, 74,
   (((((uintmax_t) 0xba8aU << 28 | 0x4084821U)
      << 28 | 0xa94f02bU)
     << 28 | 0xd02df34U)
    << 28 | 0xf695349U),
   UINTMAX_MAX / 3833)
P (14, 64,
   (((((uintmax_t) 0x1f9bU << 28 | 0xea70762U)
      << 28 | 0xf3f48ddU)
     << 28 | 0xfecd5beU)
    << 28 | 0x62e2eb7U),
   UINTMAX_MAX / 3847)
P (4, 66,
   (((((uintmax_t) 0xb7acU << 28 | 0x817ee73U)
      << 28 | 0x45119dbU)
     << 28 | 0xf849ebeU)
    << 28 | 0xc96c4a3U),
   UINTMAX_MAX / 3851)
P (2, 66,
   (((((uintmax_t) 0xf8c2U << 28 | 0x0286585U)
      << 28 | 0xe14dcdaU)
     << 28 | 0x31d4d01U)
    << 28 | 0x87357c5U),
   UINTMAX_MAX / 3853)
P (10, 60,
   (((((uintmax_t) 0x7727U << 28 | 0x2a58ab3U)
      << 28 | 0xdb276e3U)
     << 28 | 0x4e21cc2U)
    << 28 | 0xd5418a7U),
   UINTMAX_MAX / 3863)
P (14, 52,
   (((((uintmax_t) 0x61caU << 28 | 0x83edc68U)
      << 28 | 0xdb38968U)
     << 28 | 0xca5137aU)
    << 28 | 0x9e574adU),
   UINTMAX_MAX / 3877)
P (4, 50,
   (((((uintmax_t) 0x74f3U << 28 | 0x8879e60U)
      << 28 | 0x2c53a3eU)
     << 28 | 0xaa0d0f8U)
    << 28 | 0x04bfd19U),
   UINTMAX_MAX / 3881)
P (8, 54,
   (((((uintmax_t) 0x1c6fU << 28 | 0xe7c6996U)
      << 28 | 0x04df055U)
     << 28 | 0x4fb753cU)
    << 28 | 0xc20e9d1U),
   UINTMAX_MAX / 3889)
P (18, 40,
   (((((uintmax_t) 0x374dU << 28 | 0x408a62aU)
      << 28 | 0xda31679U)
     << 28 | 0x7afcca1U)
    << 28 | 0x300756bU),
   UINTMAX_MAX / 3907)
P (4, 56,
   (((((uintmax_t) 0xc8e2U << 28 | 0xbdb1524U)
      << 28 | 0x758f48bU)
     << 28 | 0x8d950b5U)
    << 28 | 0x2eeea77U),
   UINTMAX_MAX / 3911)
P (6, 72,
   (((((uintmax_t) 0xbfc1U << 28 | 0x421336fU)
      << 28 | 0x6ea5dfbU)
     << 28 | 0x6cd166aU)
    << 28 | 0xcabc185U),
   UINTMAX_MAX / 3917)
P (2, 82,
   (((((uintmax_t) 0x7daeU << 28 | 0x58b5560U)
      << 28 | 0x7b5454eU)
     << 28 | 0xb6c5ed9U)
    << 28 | 0x437a7afU),
   UINTMAX_MAX / 3919)
P (4, 80,
   (((((uintmax_t) 0xf1f8U << 28 | 0x4cbdc3dU)
      << 28 | 0x573f5d1U)
     << 28 | 0xeddbd91U)
    << 28 | 0xb790cdbU),
   UINTMAX_MAX / 3923)
P (6, 78,
   (((((uintmax_t) 0xa6abU << 28 | 0x9f4ec63U)
      << 28 | 0x4c6db93U)
     << 28 | 0xd714ea4U)
    << 28 | 0xd8948e9U),
   UINTMAX_MAX / 3929)
P (2, 82,
   (((((uintmax_t) 0x8198U << 28 | 0x742e1b7U)
      << 28 | 0xb68a73cU)
     << 28 | 0xa13ed81U)
    << 28 | 0x45188d3U),
   UINTMAX_MAX / 3931)
P (12, 76,
   (((((uintmax_t) 0x5ab3U << 28 | 0x52c7947U)
      << 28 | 0xbe09382U)
     << 28 | 0x9086016U)
    << 28 | 0xda89c57U),
   UINTMAX_MAX / 3943)
P (4, 74,
   (((((uintmax_t) 0xec69U << 28 | 0x9751239U)
      << 28 | 0xb9900d7U)
     << 28 | 0xda1f432U)
    << 28 | 0x124a543U),
   UINTMAX_MAX / 3947)
P (20, 60,
   (((((uintmax_t) 0xa4e1U << 28 | 0x58dc715U)
      << 28 | 0x1a22b7eU)
     << 28 | 0xad55816U)
    << 28 | 0x32fb07fU),
   UINTMAX_MAX / 3967)
P (22, 60,
   (((((uintmax_t) 0x4cd1U << 28 | 0xba8fa08U)
      << 28 | 0x1613a35U)
     << 28 | 0x443837fU)
    << 28 | 0x63ec3bdU),
   UINTMAX_MAX / 3989)
P (12, 50,
   (((((uintmax_t) 0x48afU << 28 | 0x92759a4U)
      << 28 | 0x3f37589U)
     << 28 | 0xe2b200eU)
    << 28 | 0x5519461U),
   UINTMAX_MAX / 4001)
P (2, 54,
   (((((uintmax_t) 0x9293U << 28 | 0xfc29b25U)
      << 28 | 0xcbafee9U)
     << 28 | 0xae44f0bU)
    << 28 | 0x7289c0bU),
   UINTMAX_MAX / 4003)
P (4, 66,
   (((((uintmax_t) 0xc02cU << 28 | 0xfa2fa91U)
      << 28 | 0xcaf9094U)
     << 28 | 0x387a277U)
    << 28 | 0xb9fa817U),
   UINTMAX_MAX / 4007)
P (6, 66,
   (((((uintmax_t) 0x15c0U << 28 | 0xd8627efU)
      << 28 | 0x28a2cc8U)
     << 28 | 0x4f1a58aU)
    << 28 | 0xbfc2c25U),
   UINTMAX_MAX / 4013)
P (6, 72,
   (((((uintmax_t) 0x1143U << 28 | 0x12ca6e3U)
      << 28 | 0x2522b71U)
     << 28 | 0x101d8e3U)
    << 28 | 0xc83377bU),
   UINTMAX_MAX / 4019)
P (2, 72,
   (((((uintmax_t) 0xcfadU << 28 | 0x7d3b04aU)
      << 28 | 0x5c91ec0U)
     << 28 | 0x24abe5cU)
    << 28 | 0x50ba69dU),
   UINTMAX_MAX / 4021)
P (6, 72,
   (((((uintmax_t) 0x9d46U << 28 | 0x3eef687U)
      << 28 | 0x26d7815U)
     << 28 | 0xde4eb36U)
    << 28 | 0x5a65d73U),
   UINTMAX_MAX / 4027)
P (22, 62,
   (((((uintmax_t) 0xe98eU << 28 | 0x1152e37U)
      << 28 | 0xc3cf309U)
     << 28 | 0xed28a76U)
    << 28 | 0xbcca931U),
   UINTMAX_MAX / 4049)
P (2, 76,
   (((((uintmax_t) 0xa002U << 28 | 0x05affefU)
      << 28 | 0xd280081U)
     << 28 | 0x6bffbf4U)
    << 28 | 0xa00205bU),
   UINTMAX_MAX / 4051)
P (6, 72,
   (((((uintmax_t) 0x1d87U << 28 | 0xfb74ed0U)
      << 28 | 0x1b4271fU)
     << 28 | 0x5c71543U)
    << 28 | 0xd558069U),
   UINTMAX_MAX / 4057)
P (16, 60,
   (((((uintmax_t) 0x7051U << 28 | 0x751852fU)
      << 28 | 0x74370f2U)
     << 28 | 0x5c64d0eU)
    << 28 | 0xc53b859U),
   UINTMAX_MAX / 4073)
P (6, 60,
   (((((uintmax_t) 0x88e1U << 28 | 0x6f867eeU)
      << 28 | 0x6d54296U)
     << 28 | 0xc02c2efU)
    << 28 | 0x1e0ff0fU),
   UINTMAX_MAX / 4079)
P (12, 62,
   (((((uintmax_t) 0xe8e8U << 28 | 0xc8bebb9U)
      << 28 | 0xaa05219U)
     << 28 | 0xa804816U)
    << 28 | 0x870a333U),
   UINTMAX_MAX / 4091)
P (2, 64,
   (((((uintmax_t) 0xc605U << 28 | 0x20f62e2U)
      << 28 | 0x8a79f6dU)
     << 28 | 0xe49add0U)
    << 28 | 0x971c555U),
   UINTMAX_MAX / 4093)
P (6, 60,
   (((((uintmax_t) 0x46c2U << 28 | 0xbb7cd89U)
      << 28 | 0x7639d52U)
     << 28 | 0x8087e68U)
    << 28 | 0x4c71aabU),
   UINTMAX_MAX / 4099)
P (12, 66,
   (((((uintmax_t) 0xfc73U << 28 | 0x53e15cbU)
      << 28 | 0x9127ea9U)
     << 28 | 0x4152c26U)
    << 28 | 0x9bcdeefU),
   UINTMAX_MAX / 4111)
P (16, 74,
   (((((uintmax_t) 0x3d78U << 28 | 0xe5c2d68U)
      << 28 | 0x0673803U)
     << 28 | 0x79450a3U)
    << 28 | 0xc2b6bdfU),
   UINTMAX_MAX / 4127)
P (2, 82,
   (((((uintmax_t) 0x4a66U << 28 | 0x8c7e3baU)
      << 28 | 0x4fbb8d2U)
     << 28 | 0xcd38bafU)
    << 28 | 0xe5373e1U),
   UINTMAX_MAX / 4129)
P (4, 84,
   (((((uintmax_t) 0x616eU << 28 | 0xb008eb5U)
      << 28 | 0xfb2b2c2U)
     << 28 | 0x9df2beaU)
    << 28 | 0x71d8badU),
   UINTMAX_MAX / 4133)
P (6, 80,
   (((((uintmax_t) 0x12bdU << 28 | 0xa25ba9aU)
      << 28 | 0x80c5ec1U)
     << 28 | 0x5862775U)
    << 28 | 0xf302e83U),
   UINTMAX_MAX / 4139)
P (14, 76,
   (((((uintmax_t) 0x98dfU << 28 | 0x642b264U)
      << 28 | 0x7a0d310U)
     << 28 | 0x16af2feU)
    << 28 | 0x55ede09U),
   UINTMAX_MAX / 4153)
P (4, 74,
   (((((uintmax_t) 0xcc45U << 28 | 0x381a1c7U)
      << 28 | 0x3878b3dU)
     << 28 | 0x26dbd9dU)
    << 28 | 0x1910715U),
   UINTMAX_MAX / 4157)
P (2, 82,
   (((((uintmax_t) 0x1344U << 28 | 0x23b36d8U)
      << 28 | 0x0d4ba62U)
     << 28 | 0x1dab2dfU)
    << 28 | 0xaf3dfbfU),
   UINTMAX_MAX / 4159)
P (18, 66,
   (((((uintmax_t) 0xd614U << 28 | 0x399c587U)
      << 28 | 0xff827b6U)
     << 28 | 0xf1d7ac2U)
    << 28 | 0x87338b1U),
   UINTMAX_MAX / 4177)
P (24, 52,
   (((((uintmax_t) 0x5c04U << 28 | 0x24ce751U)
      << 28 | 0xf620c8dU)
     << 28 | 0x9e9f0c3U)
    << 28 | 0xf9e7fd9U),
   UINTMAX_MAX / 4201)
P (10, 48,
   (((((uintmax_t) 0xa4cfU << 28 | 0x6d1fac5U)
      << 28 | 0x93e8e60U)
     << 28 | 0xa93f876U)
    << 28 | 0x2e914bbU),
   UINTMAX_MAX / 4211)
P (6, 44,
   (((((uintmax_t) 0x16b4U << 28 | 0x4c7d8a9U)
      << 28 | 0x7e358b1U)
     << 28 | 0x4371f24U)
    << 28 | 0x7c159c9U),
   UINTMAX_MAX / 4217)
P (2, 52,
   (((((uintmax_t) 0x7d2dU << 28 | 0xb0c132cU)
      << 28 | 0x9926a6dU)
     << 28 | 0xd3b4844U)
    << 28 | 0x71d4eb3U),
   UINTMAX_MAX / 4219)
P (10, 44,
   (((((uintmax_t) 0xc12aU << 28 | 0x5044c45U)
      << 28 | 0xfa4f4cdU)
     << 28 | 0x172f470U)
    << 28 | 0x1c1684dU),
   UINTMAX_MAX / 4229)
P (2, 52,
   (((((uintmax_t) 0x3b6aU << 28 | 0xabf51beU)
      << 28 | 0x4a6c103U)
     << 28 | 0x72e686eU)
    << 28 | 0xd8bb537U),
   UINTMAX_MAX / 4231)
P (10, 48,
   (((((uintmax_t) 0x0b0bU << 28 | 0xe43ba38U)
      << 28 | 0x61105bcU)
     << 28 | 0x07f7ca6U)
    << 28 | 0x5c5b071U),
   UINTMAX_MAX / 4241)
P (2, 54,
   (((((uintmax_t) 0x1841U << 28 | 0x2954499U)
      << 28 | 0xbb949abU)
     << 28 | 0x2b6170cU)
    << 28 | 0x3f78d9bU),
   UINTMAX_MAX / 4243)
P (10, 74,
   (((((uintmax_t) 0x67e4U << 28 | 0x8d552c3U)
      << 28 | 0xde0d1f3U)
     << 28 | 0xd74f461U)
    << 28 | 0xfe6f5b5U),
   UINTMAX_MAX / 4253)
P (6, 78,
   (((((uintmax_t) 0xa030U << 28 | 0x161ea7bU)
      << 28 | 0x38ae8dbU)
     << 28 | 0xc13f4b3U)
    << 28 | 0x1f3230bU),
   UINTMAX_MAX / 4259)
P (2, 78,
   (((((uintmax_t) 0xf2a9U << 28 | 0x8b90bb7U)
      << 28 | 0x2eec1d1U)
     << 28 | 0x420716eU)
    << 28 | 0x3f1572dU),
   UINTMAX_MAX / 4261)
P (10, 78,
   (((((uintmax_t) 0xa0c1U << 28 | 0xb926e68U)
      << 28 | 0x69f8ed5U)
     << 28 | 0xbe2fd4dU)
    << 28 | 0x805464fU),
   UINTMAX_MAX / 4271)
P (2, 84,
   (((((uintmax_t) 0xc4edU << 28 | 0x7ccb753U)
      << 28 | 0xef76ec6U)
     << 28 | 0x8b97c13U)
    << 28 | 0x6943851U),
   UINTMAX_MAX / 4273)
P (10, 80,
   (((((uintmax_t) 0x5305U << 28 | 0xada2a32U)
      << 28 | 0xce35e9eU)
     << 28 | 0x27918afU)
    << 28 | 0x7cfb473U),
   UINTMAX_MAX / 4283)
P (6, 84,
   (((((uintmax_t) 0x0b38U << 28 | 0xa4bcd9fU)
      << 28 | 0xaa0cc5eU)
     << 28 | 0xc8ab6c3U)
    << 28 | 0x6ac7f41U),
   UINTMAX_MAX / 4289)
P (8, 94,
   (((((uintmax_t) 0xc8f3U << 28 | 0x8c6bf3dU)
      << 28 | 0x8adf696U)
     << 28 | 0x4076331U)
    << 28 | 0xdd90979U),
   UINTMAX_MAX / 4297)
P (30, 70,
   (((((uintmax_t) 0x3ed4U << 28 | 0xdeb0e60U)
      << 28 | 0x6fb3530U)
     << 28 | 0x198eff7U)
    << 28 | 0x7b002d7U),
   UINTMAX_MAX / 4327)
P (10, 72,
   (((((uintmax_t) 0xe304U << 28 | 0x8b8a2eaU)
      << 28 | 0x19da93aU)
     << 28 | 0xf7cb958U)
    << 28 | 0x3ece011U),
   UINTMAX_MAX / 4337)
P (2, 82,
   (((((uintmax_t) 0x63b5U << 28 | 0xa908ca7U)
      << 28 | 0xcb9bb34U)
     << 28 | 0xce06f64U)
    << 28 | 0x3d9883bU),
   UINTMAX_MAX / 4339)
P (10, 74,
   (((((uintmax_t) 0xd58fU << 28 | 0x1940b11U)
      << 28 | 0x0300879U)
     << 28 | 0xf767e52U)
    << 28 | 0x8708c55U),
   UINTMAX_MAX / 4349)
P (8, 84,
   (((((uintmax_t) 0xa973U << 28 | 0xcee1454U)
      << 28 | 0x5fa7a18U)
     << 28 | 0x5332d2eU)
    << 28 | 0xf2313cdU),
   UINTMAX_MAX / 4357)
P (6, 84,
   (((((uintmax_t) 0xc544U << 28 | 0x1f37189U)
      << 28 | 0x5bd3a43U)
     << 28 | 0xb611b84U)
    << 28 | 0xc8332a3U),
   UINTMAX_MAX / 4363)
P (10, 78,
   (((((uintmax_t) 0xc201U << 28 | 0x49b4038U)
      << 28 | 0x330c3c2U)
     << 28 | 0xe215e4fU)
    << 28 | 0x43bb63dU),
   UINTMAX_MAX / 4373)
P (18, 66,
   (((((uintmax_t) 0xfcf7U << 28 | 0xe56a2a8U)
      << 28 | 0xf4dd4f9U)
     << 28 | 0x4b9dd22U)
    << 28 | 0xce44e97U),
   UINTMAX_MAX / 4391)
P (6, 66,
   (((((uintmax_t) 0xc364U << 28 | 0x3300862U)
      << 28 | 0x47258d8U)
     << 28 | 0x95834a1U)
    << 28 | 0xdb166a5U),
   UINTMAX_MAX / 4397)
P (12, 72,
   (((((uintmax_t) 0xa5f1U << 28 | 0xb76bd2bU)
      << 28 | 0x5f83834U)
     << 28 | 0x7d2f16dU)
    << 28 | 0x19b8d09U),
   UINTMAX_MAX / 4409)
P (12, 62,
   (((((uintmax_t) 0x9b97U << 28 | 0x89df750U)
      << 28 | 0x6e4081bU)
     << 28 | 0x54d4dc4U)
    << 28 | 0x5b7d98dU),
   UINTMAX_MAX / 4421)
P (2, 70,
   (((((uintmax_t) 0x612dU << 28 | 0xe5f44efU)
      << 28 | 0x2839e11U)
     << 28 | 0x7ac30d9U)
    << 28 | 0xa044877U),
   UINTMAX_MAX / 4423)
P (18, 66,
   (((((uintmax_t) 0x9811U << 28 | 0x1015369U)
      << 28 | 0x6e9ec0eU)
     << 28 | 0x10b78a6U)
    << 28 | 0x7a526e9U),
   UINTMAX_MAX / 4441)
P (6, 66,
   (((((uintmax_t) 0xa197U << 28 | 0x1cf4c64U)
      << 28 | 0x2a99792U)
     << 28 | 0xda68a81U)
    << 28 | 0x8688a9fU),
   UINTMAX_MAX / 4447)
P (4, 66,
   (((((uintmax_t) 0x0f02U << 28 | 0xeeeb01cU)
      << 28 | 0x870bacfU)
     << 28 | 0x2b6c87fU)
    << 28 | 0x741f84bU),
   UINTMAX_MAX / 4451)
P (6, 62,
   (((((uintmax_t) 0x8d2eU << 28 | 0x94fe559U)
      << 28 | 0x50d09d2U)
     << 28 | 0x64f9bd4U)
    << 28 | 0x1e18ed9U),
   UINTMAX_MAX / 4457)
P (6, 60,
   (((((uintmax_t) 0xa84bU << 28 | 0xb74450fU)
      << 28 | 0xe38c973U)
     << 28 | 0x3cbeaa9U)
    << 28 | 0x7166d8fU),
   UINTMAX_MAX / 4463)
P (18, 66,
   (((((uintmax_t) 0x495aU << 28 | 0xe4dcfaaU)
      << 28 | 0xfd8b1c9U)
     << 28 | 0xf475b02U)
    << 28 | 0x1d22e81U),
   UINTMAX_MAX / 4481)
P (2, 66,
   (((((uintmax_t) 0x6837U << 28 | 0x46fb256U)
      << 28 | 0x74d6073U)
     << 28 | 0x1f76f2eU)
    << 28 | 0xc4c852bU),
   UINTMAX_MAX / 4483)
P (10, 68,
   (((((uintmax_t) 0xf6ffU << 28 | 0x5f8d222U)
      << 28 | 0x12931daU)
     << 28 | 0xf6f0c97U)
    << 28 | 0x8f69945U),
   UINTMAX_MAX / 4493)
P (14, 60,
   (((((uintmax_t) 0xd49aU << 28 | 0xb982b2bU)
      << 28 | 0x1c92174U)
     << 28 | 0x9c8ad20U)
    << 28 | 0xc61ec93U),
   UINTMAX_MAX / 4507)
P (6, 70,
   (((((uintmax_t) 0x2f4fU << 28 | 0x04983ffU)
      << 28 | 0xc5e9e09U)
     << 28 | 0x307ff8bU)
    << 28 | 0xd3c1261U),
   UINTMAX_MAX / 4513)
P (4, 74,
   (((((uintmax_t) 0xadefU << 28 | 0x566dd5fU)
      << 28 | 0x282eb33U)
     << 28 | 0x4a69fb5U)
    << 28 | 0xa486e2dU),
   UINTMAX_MAX / 4517)
P (2, 78,
   (((((uintmax_t) 0xd118U << 28 | 0x137ccc9U)
      << 28 | 0xe647f1fU)
     << 28 | 0x36c7bf3U)
    << 28 | 0x1578617U),
   UINTMAX_MAX / 4519)
P (4, 80,
   (((((uintmax_t) 0x01cfU << 28 | 0xa9f7f67U)
      << 28 | 0xdc3aa31U)
     << 28 | 0xebbcc27U)
    << 28 | 0x9ea6103U),
   UINTMAX_MAX / 4523)
P (24, 74,
   (((((uintmax_t) 0x9c1fU << 28 | 0x4da38ddU)
      << 28 | 0x2657442U)
     << 28 | 0xe2aad11U)
    << 28 | 0x9f466ebU),
   UINTMAX_MAX / 4547)
P (2, 88,
   (((((uintmax_t) 0x41acU << 28 | 0x994bcdcU)
      << 28 | 0xd3d2c10U)
     << 28 | 0x6ec05a0U)
    << 28 | 0xab1450dU),
   UINTMAX_MAX / 4549)
P (12, 78,
   (((((uintmax_t) 0x556dU << 28 | 0x480324aU)
      << 28 | 0x6d002b1U)
     << 28 | 0xb38db92U)
    << 28 | 0xa99e731U),
   UINTMAX_MAX / 4561)
P (6, 76,
   (((((uintmax_t) 0x9c39U << 28 | 0x2ce6456U)
      << 28 | 0x52d9278U)
     << 28 | 0x4ae377eU)
    << 28 | 0x67071e7U),
   UINTMAX_MAX / 4567)
P (16, 66,
   (((((uintmax_t) 0xcdc8U << 28 | 0x79fec56U)
      << 28 | 0x781893eU)
     << 28 | 0x9e1471bU)
    << 28 | 0xa6671d7U),
   UINTMAX_MAX / 4583)
P (8, 60,
   (((((uintmax_t) 0x375eU << 28 | 0xf621586U)
      << 28 | 0x1b19982U)
     << 28 | 0xc29b59dU)
    << 28 | 0x4d73d0fU),
   UINTMAX_MAX / 4591)
P (6, 60,
   (((((uintmax_t) 0x75c7U << 28 | 0xfa35597U)
      << 28 | 0xdcce0c2U)
     << 28 | 0x3dd0712U)
    << 28 | 0x8b5525dU),
   UINTMAX_MAX / 4597)
P (6, 60,
   (((((uintmax_t) 0x4083U << 28 | 0xb2ce1ccU)
      << 28 | 0xf1d164dU)
     << 28 | 0x4e5ce0eU)
    << 28 | 0x9245133U),
   UINTMAX_MAX / 4603)
P (18, 52,
   (((((uintmax_t) 0x9d9cU << 28 | 0x64622aeU)
      << 28 | 0x10824c8U)
     << 28 | 0xfd1057cU)
    << 28 | 0x09f8cc5U),
   UINTMAX_MAX / 4621)
P (16, 42,
   (((((uintmax_t) 0x02b4U << 28 | 0x87cfdbcU)
      << 28 | 0x89230eaU)
     << 28 | 0x1516e94U)
    << 28 | 0xf394035U),
   UINTMAX_MAX / 4637)
P (2, 52,
   (((((uintmax_t) 0x32e1U << 28 | 0x4328c7fU)
      << 28 | 0xce8e0b5U)
     << 28 | 0xe3319c5U)
    << 28 | 0x64ee9dfU),
   UINTMAX_MAX / 4639)
P (4, 60,
   (((((uintmax_t) 0xf929U << 28 | 0xbd10602U)
      << 28 | 0x894a612U)
     << 28 | 0x6a69f90U)
    << 28 | 0xd822d8bU),
   UINTMAX_MAX / 4643)
P (6, 72,
   (((((uintmax_t) 0xa0bcU << 28 | 0x8b6d15cU)
      << 28 | 0x03be950U)
     << 28 | 0x1ed6348U)
    << 28 | 0x857aa19U),
   UINTMAX_MAX / 4649)
P (2, 72,
   (((((uintmax_t) 0xf169U << 28 | 0xf4a94f1U)
      << 28 | 0x86231deU)
     << 28 | 0x344a324U)
    << 28 | 0xeee1c83U),
   UINTMAX_MAX / 4651)
P (6, 72,
   (((((uintmax_t) 0xafdaU << 28 | 0x2e10d23U)
      << 28 | 0x58ab11dU)
     << 28 | 0xd9690cbU)
    << 28 | 0x2c406d1U),
   UINTMAX_MAX / 4657)
P (6, 70,
   (((((uintmax_t) 0x70eeU << 28 | 0x0c3017bU)
      << 28 | 0x7881908U)
     << 28 | 0xd6c5178U)
    << 28 | 0xd5e4387U),
   UINTMAX_MAX / 4663)
P (10, 78,
   (((((uintmax_t) 0x2b47U << 28 | 0x45bd0e3U)
      << 28 | 0x051844cU)
     << 28 | 0xea4050aU)
    << 28 | 0x3e8fdc1U),
   UINTMAX_MAX / 4673)
P (6, 80,
   (((((uintmax_t) 0x5aa8U << 28 | 0x9fc2b8dU)
      << 28 | 0x1a891c1U)
     << 28 | 0x14a06acU)
    << 28 | 0xc83f777U),
   UINTMAX_MAX / 4679)
P (12, 92,
   (((((uintmax_t) 0x834dU << 28 | 0x385f9c7U)
      << 28 | 0x5a89320U)
     << 28 | 0xb060ebcU)
    << 28 | 0x0ea01dbU),
   UINTMAX_MAX / 4691)
P (12, 84,
   (((((uintmax_t) 0xcbb0U << 28 | 0x86fea3aU)
      << 28 | 0x06a40feU)
     << 28 | 0x50045acU)
    << 28 | 0xb78c99fU),
   UINTMAX_MAX / 4703)
P (18, 68,
   (((((uintmax_t) 0x4bceU << 28 | 0xc35242bU)
      << 28 | 0x29eaa29U)
     << 28 | 0x1a68705U)
    << 28 | 0xb196e91U),
   UINTMAX_MAX / 4721)
P (2, 70,
   (((((uintmax_t) 0x1cf1U << 28 | 0xbea1a20U)
      << 28 | 0x324cdc1U)
     << 28 | 0x042c724U)
    << 28 | 0x273e2bbU),
   UINTMAX_MAX / 4723)
P (6, 70,
   (((((uintmax_t) 0x530aU << 28 | 0xaa16d83U)
      << 28 | 0x622522cU)
     << 28 | 0xee680bbU)
    << 28 | 0x165b7c9U),
   UINTMAX_MAX / 4729)
P (4, 68,
   (((((uintmax_t) 0x6dbeU << 28 | 0xc4fd598U)
      << 28 | 0x42343fdU)
     << 28 | 0x2ff9f12U)
    << 28 | 0xe0776d5U),
   UINTMAX_MAX / 4733)
P (18, 62,
   (((((uintmax_t) 0x9327U << 28 | 0xd1e0357U)
      << 28 | 0x3cba016U)
     << 28 | 0x6a5da63U)
    << 28 | 0xaf2cc6fU),
   UINTMAX_MAX / 4751)
P (8, 58,
   (((((uintmax_t) 0xfe7eU << 28 | 0x69c1b53U)
      << 28 | 0xa5d7dedU)
     << 28 | 0xd16a593U)
    << 28 | 0x0408d27U),
   UINTMAX_MAX / 4759)
P (24, 48,
   (((((uintmax_t) 0xdba8U << 28 | 0x6fc17c3U)
      << 28 | 0xa04d12aU)
     << 28 | 0xdf30c26U)
    << 28 | 0x528844fU),
   UINTMAX_MAX / 4783)
P (4, 74,
   (((((uintmax_t) 0x4928U << 28 | 0x7ba43b4U)
      << 28 | 0x0f9d99aU)
     << 28 | 0x48d6572U)
    << 28 | 0xb5eec7bU),
   UINTMAX_MAX / 4787)
P (2, 82,
   (((((uintmax_t) 0xfd7cU << 28 | 0xd1c2bd5U)
      << 28 | 0x72fbc6eU)
     << 28 | 0x8bf2877U)
    << 28 | 0x503cb9dU),
   UINTMAX_MAX / 4789)
P (4, 84,
   (((((uintmax_t) 0x1951U << 28 | 0x21b3d5eU)
      << 28 | 0x975e0eaU)
     << 28 | 0x27a191aU)
    << 28 | 0x7045389U),
   UINTMAX_MAX / 4793)
P (6, 90,
   (((((uintmax_t) 0xced1U << 28 | 0x00e827bU)
      << 28 | 0x0325b6eU)
     << 28 | 0xb091f34U)
    << 28 | 0xdd45d3fU),
   UINTMAX_MAX / 4799)
P (2, 102,
   (((((uintmax_t) 0xe394U << 28 | 0x4a02e12U)
      << 28 | 0x05dd8dcU)
     << 28 | 0x8a6cabbU)
    << 28 | 0x2937d41U),
   UINTMAX_MAX / 4801)
P (12, 96,
   (((((uintmax_t) 0x3e2dU << 28 | 0xa2eb33fU)
      << 28 | 0x746e6bcU)
     << 28 | 0x2f04f25U)
    << 28 | 0x4922a05U),
   UINTMAX_MAX / 4813)
P (4, 102,
   (((((uintmax_t) 0xf205U << 28 | 0xd890fadU)
      << 28 | 0x84cf441U)
     << 28 | 0x431f4d6U)
    << 28 | 0xeb38631U),
   UINTMAX_MAX / 4817)
P (14, 100,
   (((((uintmax_t) 0x7974U << 28 | 0xa2271b8U)
      << 28 | 0x09c017bU)
     << 28 | 0xd717435U)
    << 28 | 0xa08291fU),
   UINTMAX_MAX / 4831)
P (30, 72,
   (((((uintmax_t) 0xf434U << 28 | 0x0837312U)
      << 28 | 0x2b4a342U)
     << 28 | 0x32df9c9U)
    << 28 | 0x1fc1a55U),
   UINTMAX_MAX / 4861)
P (10, 66,
   (((((uintmax_t) 0x4c78U << 28 | 0x09ab985U)
      << 28 | 0xc13f8a4U)
     << 28 | 0x651e1d5U)
    << 28 | 0x382eab7U),
   UINTMAX_MAX / 4871)
P (6, 66,
   (((((uintmax_t) 0x9273U << 28 | 0x60376e4U)
      << 28 | 0x8c0bf7cU)
     << 28 | 0xfb5409dU)
    << 28 | 0xe4cf3c5U),
   UINTMAX_MAX / 4877)
P (12, 62,
   (((((uintmax_t) 0x47a1U << 28 | 0xbf627e6U)
      << 28 | 0x7276dcdU)
     << 28 | 0xd636fb0U)
    << 28 | 0x68b9929U),
   UINTMAX_MAX / 4889)
P (14, 54,
   (((((uintmax_t) 0x3f55U << 28 | 0x93b5db8U)
      << 28 | 0xe2d01eeU)
     << 28 | 0x8f95e74U)
    << 28 | 0x0462c97U),
   UINTMAX_MAX / 4903)
P (6, 58,
   (((((uintmax_t) 0x29aaU << 28 | 0xc9d12b8U)
      << 28 | 0xb650349U)
     << 28 | 0x0f97b3aU)
    << 28 | 0x758b4a5U),
   UINTMAX_MAX / 4909)
P (10, 50,
   (((((uintmax_t) 0x3c51U << 28 | 0x65394caU)
      << 28 | 0x8d3eb64U)
     << 28 | 0x1431563U)
    << 28 | 0xc441287U),
   UINTMAX_MAX / 4919)
P (12, 42,
   (((((uintmax_t) 0xf258U << 28 | 0x91c808bU)
      << 28 | 0x8d292b7U)
     << 28 | 0x43dad3eU)
    << 28 | 0xc45916bU),
   UINTMAX_MAX / 4931)
P (2, 54,
   (((((uintmax_t) 0x708fU << 28 | 0xa57e92aU)
      << 28 | 0x8098c7bU)
     << 28 | 0x188be8fU)
    << 28 | 0x55c878dU),
   UINTMAX_MAX / 4933)
P (4, 56,
   (((((uintmax_t) 0x983dU << 28 | 0xcf2775dU)
      << 28 | 0xcd7ead8U)
     << 28 | 0x05648b2U)
    << 28 | 0xca54ef9U),
   UINTMAX_MAX / 4937)
P (6, 56,
   (((((uintmax_t) 0x729cU << 28 | 0xb7c09bcU)
      << 28 | 0x91a2776U)
     << 28 | 0xdbe6eefU)
    << 28 | 0x60123afU),
   UINTMAX_MAX / 4943)
P (8, 255,
   (((((uintmax_t) 0xe8f0U << 28 | 0x5536727U)
      << 28 | 0xa8b8137U)
     << 28 | 0x11525e6U)
    << 28 | 0xa9e8867U),
   UINTMAX_MAX / 4951)
P (6, 255,
   (((((uintmax_t) 0xbdf2U << 28 | 0x781fd01U)
      << 28 | 0x3014a85U)
     << 28 | 0xc2215cbU)
    << 28 | 0x383d8f5U),
   UINTMAX_MAX / 4957)
P (10, 255,
   (((((uintmax_t) 0x0439U << 28 | 0xee5f8e3U)
      << 28 | 0x30656e5U)
     << 28 | 0x8f554c8U)
    << 28 | 0x9825857U),
   UINTMAX_MAX / 4967)
P (2, 255,
   (((((uintmax_t) 0x77adU << 28 | 0xfb283c9U)
      << 28 | 0x63b0a8fU)
     << 28 | 0xbd3b17cU)
    << 28 | 0x01dacd9U),
   UINTMAX_MAX / 4969)
P (4, 255,
   (((((uintmax_t) 0x5d7bU << 28 | 0xe851f3fU)
      << 28 | 0x443554cU)
     << 28 | 0x8c39dc7U)
    << 28 | 0xaedee65U),
   UINTMAX_MAX / 4973)
P (14, 255,
   (((((uintmax_t) 0x373cU << 28 | 0x1c8a99bU)
      << 28 | 0x1412465U)
     << 28 | 0x3ac6ddaU)
    << 28 | 0x86cd3b3U),
   UINTMAX_MAX / 4987)
P (6, 255,
   (((((uintmax_t) 0x5b50U << 28 | 0xa687decU)
      << 28 | 0x6a07b0dU)
     << 28 | 0x61c6791U)
    << 28 | 0xa9c2c81U),
   UINTMAX_MAX / 4993)
P (6, 255,
   (((((uintmax_t) 0x0b44U << 28 | 0x292c4bfU)
      << 28 | 0xef9cdb6U)
     << 28 | 0x27a3009U)
    << 28 | 0x0354237U),
   UINTMAX_MAX / 4999)

#undef FIRST_OMITTED_PRIME
#define FIRST_OMITTED_PRIME 5003
