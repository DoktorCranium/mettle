#include <config.h>
#define FCHOWNAT_INLINE _GL_EXTERN_INLINE
#include "openat.h"
