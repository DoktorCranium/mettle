#include <stddef.h>
int xmemcoll (char *, size_t, char *, size_t);
int xmemcoll0 (char const *, size_t, char const *, size_t);
